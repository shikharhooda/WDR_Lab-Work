package com.softcrayons.usersmanagementsystem.service;

import java.util.List;

import com.softcrayons.usersmanagementsystem.dto.student.StudentDto;

public interface StudentService {
    StudentDto createStudent(StudentDto studentDto);
    StudentDto updateStudentById(Integer id, StudentDto studentDto);
    StudentDto getStudentById(Integer id);
    List<StudentDto> getAllStudents();
    void deleteStudentById(Integer id);
    
    StudentDto getStudentByStudentId(String studentId);
    StudentDto updateStudentByStudentId(String studentId, StudentDto studentDto);
    void deleteStudentByStudentId(String studentId);

    StudentDto getStudentByEmail(String email);
    StudentDto updateStudentByEmail(String email, StudentDto studentDto);
    void deleteStudentByEmail(String email);
}

