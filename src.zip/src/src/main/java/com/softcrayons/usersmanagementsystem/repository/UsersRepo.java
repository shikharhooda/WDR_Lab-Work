package com.softcrayons.usersmanagementsystem.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.softcrayons.usersmanagementsystem.entity.OurUsers;

import jakarta.transaction.Transactional;

import java.util.Optional;

public interface UsersRepo extends JpaRepository<OurUsers, Integer> {

    Optional<OurUsers> findByEmail(String email);
   
    @Transactional
    int deleteByEmail(String email);

}
