package com.softcrayons.usersmanagementsystem;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
 import org.springframework.cache.annotation.EnableCaching;

@SpringBootApplication
@EnableCaching
public class Softcrayons{
	public static void main(String[] args) {
		SpringApplication.run(Softcrayons.class, args);
	}
}
  