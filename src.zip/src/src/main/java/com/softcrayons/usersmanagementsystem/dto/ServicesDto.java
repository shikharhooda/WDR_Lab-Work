package com.softcrayons.usersmanagementsystem.dto;
import lombok.Data;

@Data
public class ServicesDto {
    private Integer id;
    private String name;
    private String seoUrl;
    private String shortDescription;
    private String mediumDescription;
    private String longDescription;
    private String description;
    private String metaTitle;
    private String metaKeywords;
    private String metaDescription;
    private String templete;
    private String publish;
    private String footerSection;
    private String headerSection;
}
