package com.softcrayons.usersmanagementsystem.controller;
import com.softcrayons.usersmanagementsystem.dto.student.StudentDto;
import com.softcrayons.usersmanagementsystem.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class StudentController {

    @Autowired
    private StudentService service;

 

    @PostMapping("/admin/addstudent")
    public StudentDto create(@RequestBody StudentDto dto) {
        // System.out.println("Getting called");
        return service.createStudent(dto);
    }

    @PutMapping("/auth/{id}")
    public StudentDto update(@PathVariable Integer id, @RequestBody StudentDto dto) {
        return service.updateStudentById(id, dto);
    }

    @GetMapping("/auth/{id}")
    public StudentDto getById(@PathVariable Integer id) {
        return service.getStudentById(id);
    }

    @GetMapping("/auth/checkStudentIdAvailability/{id}")
    public ResponseEntity<Map<String, Object>> checkStudentIdAvailability(@PathVariable String id) {

        StudentDto student = service.getStudentByStudentId(id);
        Map<String, Object> response = new HashMap<>();
        if (student == null) {
            response.put("available", true);
            response.put("message", "Student ID is available");
            return ResponseEntity.ok(response);
        } else {
            response.put("available", false);
            response.put("message", "Student ID is already taken");
            response.put("studentId", student.getStudentId());
            return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
        }
    }

    @GetMapping("/auth/all")
    public List<StudentDto> getAll() {
        return service.getAllStudents();
    }

    

    @DeleteMapping("/auth/{id}")
    public void delete(@PathVariable Integer id) {
        service.deleteStudentById(id);
    }

    @GetMapping("/auth/by-studentid/{studentId}")
    public StudentDto getByStudentId(@PathVariable String studentId) {
        return service.getStudentByStudentId(studentId);
    }

    @PutMapping("/auth/by-studentid/{studentId}")
    public StudentDto updateByStudentId(@PathVariable String studentId, @RequestBody StudentDto dto) {
        return service.updateStudentByStudentId(studentId, dto);
    }

    @DeleteMapping("/auth/by-studentid/{studentId}")
    public void deleteByStudentId(@PathVariable String studentId) {
        service.deleteStudentByStudentId(studentId);
    }

    @GetMapping("/auth/by-email/{email}")
    public StudentDto getByEmail(@PathVariable String email) {
        return service.getStudentByEmail(email);
    }

    @PutMapping("/auth/by-email/{email}")
    public StudentDto updateByEmail(@PathVariable String email, @RequestBody StudentDto dto) {
        return service.updateStudentByEmail(email, dto);
    }

    @DeleteMapping("/auth/by-email/{email}")
    public void deleteByEmail(@PathVariable String email) {
        service.deleteStudentByEmail(email);
    }

    @GetMapping("/auth/report/{studentId}")
    public String sendReport(@PathVariable String studentId) {
        System.out.println("Inside ReportService, studentId = " + studentId);
        if (studentId == null || studentId.isEmpty()) {
            return "Error: studentId is required";
        }

        try {
            System.out.println("Generating report for studentId: " + studentId); 
            return "Report sent successfully to " + studentId;
        } catch (Exception e) {
            e.printStackTrace();
            return "Error sending report: " + e.getMessage();
        }
    }
}
