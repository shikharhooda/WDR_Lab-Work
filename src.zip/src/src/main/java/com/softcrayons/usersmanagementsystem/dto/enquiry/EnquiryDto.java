package com.softcrayons.usersmanagementsystem.dto.enquiry;
import lombok.*;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EnquiryDto {
    private Long id;
    private String name;
    private String contact;
    private String alternateContact;
    private String course;
    private String education;
    private String duration;
    private String remarks;
    private String leadStatus;
    private String email;
    private String address;
    private LocalDate assignedDate;
    private String assignedTo;
    private LocalDate enquiryDate;
    private String working;
    private String workingRemarks;
    private String availabilityDetails;

}
