package com.softcrayons.usersmanagementsystem.controller;
import com.softcrayons.usersmanagementsystem.dto.ServicesDto;
import com.softcrayons.usersmanagementsystem.service.TopCategoriesService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
public class ServicesController {

    @Autowired
    private TopCategoriesService topCategoriesService;

    
    @PostMapping("/auth/services/add")
    public ResponseEntity<ServicesDto> create(
        @ModelAttribute ServicesDto dto,
        @RequestParam MultipartFile image,
        @RequestParam MultipartFile bannerImage
    ) throws IOException {
        return ResponseEntity.ok(topCategoriesService.createService(dto, image, bannerImage));
    }

        @PutMapping("/auth/services/{id}")
        public ResponseEntity<ServicesDto> update(
            @PathVariable Integer id,
            @ModelAttribute ServicesDto dto,
            @RequestParam MultipartFile image,
            @RequestParam MultipartFile bannerImage
        ) throws IOException {
            // System.out.println("Working  .......");
            return ResponseEntity.ok(topCategoriesService.updateService(id, dto, image, bannerImage));
        }

    @GetMapping("/{id}")
    public ResponseEntity<ServicesDto> get(@PathVariable Integer id) {
        return ResponseEntity.ok(topCategoriesService.getService(id));
    }

    @GetMapping
    public ResponseEntity<List<ServicesDto>> getAll() {
        return ResponseEntity.ok(topCategoriesService.getAllServices());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Integer id) {
        topCategoriesService.deleteService(id);
        return ResponseEntity.noContent().build();
    }
}
