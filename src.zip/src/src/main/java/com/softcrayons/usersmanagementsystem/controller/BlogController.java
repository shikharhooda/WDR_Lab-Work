package com.softcrayons.usersmanagementsystem.controller;
import com.softcrayons.usersmanagementsystem.dto.blos.BlogDto;
import com.softcrayons.usersmanagementsystem.service.BlogService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController

public class BlogController {

    private final BlogService blogService;

    public BlogController(BlogService blogService) {
        this.blogService = blogService;
    }

   @PostMapping("auth/blog/add_blog")
public ResponseEntity<?> createBlog(@ModelAttribute BlogDto blogDto) {
    try {
        // System.out.println("==========Working==========================");
        // System.out.println("ImageFile = " + blogDto.getImageFile());
        // System.out.println("FeatureImageFile = " + blogDto.getFeatureImageFile());
        // System.out.println("category = " + blogDto.getBlogCategoryId());
        // System.out.println("Url " + blogDto.getSeoUrl());
        // System.out.println("title " + blogDto.getTitle());

        BlogDto savedBlog = blogService.createBlog(blogDto);
        return ResponseEntity.ok(savedBlog);
    } catch (Exception e) {
        e.printStackTrace();
        return ResponseEntity
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Map.of(
                    "success", false,
                    "message", "Error: " + e.getMessage()
                ));
    }
}


    @PutMapping("/auth/blog/{url}")
    public ResponseEntity<BlogDto> updateBlog(@PathVariable String url, @ModelAttribute BlogDto blogDto) {
        return ResponseEntity.ok(blogService.updateBlog(url, blogDto));
    }

    @DeleteMapping("auth/blog/{id}")
    public ResponseEntity<Void> deleteBlog(@PathVariable Long id) {
        blogService.deleteBlog(id);
        return ResponseEntity.noContent().build();  
    }


     @GetMapping("/public/blog/{seoUrl}")
    public ResponseEntity<BlogDto> getBlog(@PathVariable String seoUrl) {
        return ResponseEntity.ok(blogService.getBlog(seoUrl));
    }

   @GetMapping("/public/blog/is_exist_url/{seoUrl}")
   public ResponseEntity<Map<String, Object>> isAvailable(@PathVariable String seoUrl) {
        try {
            if (seoUrl == null || seoUrl.trim().isEmpty()) {
                return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", "SEO URL must not be empty"
                ));
            }

            boolean available = blogService.isAvailable(seoUrl);

            return ResponseEntity.ok(Map.of(
                "success", true,
                "seoUrl", seoUrl,
                "available", available
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
                "success", false,
                "message", "An error occurred while checking SEO URL",
                "error", e.getMessage()
            ));
        }
    }


    @GetMapping("public/blog")
    public ResponseEntity<List<BlogDto>> getAllBlogs() {
        return ResponseEntity.ok(blogService.getAllBlogs());
    }
}
