package com.softcrayons.usersmanagementsystem.entity;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "blog_categories")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BlogCategory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String title;

    @Column(name = "seo_url", nullable = false)
    private String seoUrl;

    private String image;

    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String shortDescription;

    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String benefits;

    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String longDescription;

    @Column(nullable = false)
    private String isHome;

    @Column(nullable = false)
    private String publish ;

    private String isParent;

    @Column(name = "meta_title", columnDefinition = "TEXT")
    private String metaTitle;

    @Column(name = "meta_keywords", columnDefinition = "TEXT")
    private String metaKeywords;

    @Column(name = "meta_description", columnDefinition = "TEXT")
    private String metaDescription;

    private String bannerImage;

    @Column(nullable = false)
    private String ordering;

    @Column(nullable = false)
    private String templete;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
}
