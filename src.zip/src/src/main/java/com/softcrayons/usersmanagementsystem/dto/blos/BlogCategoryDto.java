package com.softcrayons.usersmanagementsystem.dto.blos;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class BlogCategoryDto {
     private Integer id;
    private String title;
    private String seoUrl;
    private String image;         
    private String bannerImage;   
    private String shortDescription;
    private String benefits;
    private String longDescription;
    private Boolean isHome;
    private String publish;
    private Integer isParent;
    private String metaTitle;
    private String metaKeywords;
    private String metaDescription;
    private Integer ordering;
    private String templete;
    
}
