package com.softcrayons.usersmanagementsystem.exception;
public class InvalidImageFormatException extends RuntimeException {
    public InvalidImageFormatException(String message) {
        super(message);
    }
}
