package com.softcrayons.usersmanagementsystem.dto.enquiry;


import lombok.*;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CertificateEnquiryDto {

    private Long id;

    private String name;

    private String contact;

    private String email;

    private String course;

    private String trainer;

    private String message;

    private String address;

    private Boolean agreed;
    
}




