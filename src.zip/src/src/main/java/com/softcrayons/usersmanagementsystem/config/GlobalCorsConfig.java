package com.softcrayons.usersmanagementsystem.config;
import org.springframework.context.annotation.Configuration;



@Configuration
public class GlobalCorsConfig {

    // @Bean
    // public CorsFilter corsFilter() {
    //     CorsConfiguration config = new CorsConfiguration();
    //     config.setAllowedOrigins(List.of(
    //             "https://softcrayons.com",
    //             "https://www.softcrayons.com",
    //             "http://localhost:5173",
    //              "https://chat-bot-softcrayons.vercel.app",
    //             "https://chat-bot-softcrayons-6jca06hlx-gsdwiwedis-projects.vercel.app"
    //     ));
    //     config.setAllowCredentials(true);
    //     config.setAllowedHeaders(List.of("*"));
    //     config.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
    //     config.setExposedHeaders(List.of("Authorization", "Content-Type"));

    //     UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
    //     source.registerCorsConfiguration("/**", config);
    //     return new CorsFilter(source);
    // }
}
