package com.softcrayons.usersmanagementsystem.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "blogs")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Blog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String title;

    @Column(name = "seo_url", nullable = false)
    private String seoUrl;

    private String image;

    @Column(nullable = false)
    private String publish;

    // Long text values start here
    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String longDescription;

    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String shortDescription;

    @Column(name = "meta_description", columnDefinition = "TEXT")
    private String metaDescription;

    @Column(name = "meta_keywords", columnDefinition = "TEXT")
    private String metaKeywords;

    @Column(name = "meta_title", columnDefinition = "TEXT")
    private String metaTitle;
    // Long text values end here

    @Column(name = "featureImage")
    private String featureImage;

    @Column(name = "blog_category_id", nullable = false)
    private String blogCategoryId;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Column(name = "agent_id")
    private Integer agentId;

    @Column(nullable = false)
    private String status ;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
}
