package com.softcrayons.usersmanagementsystem.service;

import com.softcrayons.usersmanagementsystem.dto.PropertyDTO;
import com.softcrayons.usersmanagementsystem.entity.Property;


import org.springframework.stereotype.Component;

@Component

public class PropertyMapper {

    public Property toEntity(PropertyDTO dto) {
        return Property.builder()
                .id(dto.getId())
                .name(dto.getName())
                .seoUrl(dto.getSeoUrl())
                .heading(dto.getHeading())
                .price(dto.getPrice())
                .address(dto.getAddress())
                .mobile(dto.getMobile())
                .email(dto.getEmail())
                .website(dto.getWebsite())
                .shortDescription(dto.getShortDescription())
                .longDescription(dto.getLongDescription())
                .description(dto.getDescription())
                .cancellationPolicy(dto.getCancellationPolicy())
                .bookingPolicy(dto.getBookingPolicy())
                .notes(dto.getNotes())
                .featureImage(dto.getFeatureImage())
                .status(dto.getStatus())
                .metaTitle(dto.getMetaTitle())
                .metaKeywords(dto.getMetaKeywords())
                .metaDescription(dto.getMetaDescription())
                .headerSection(dto.getHeaderSection())
                .footerSection(dto.getFooterSection())
                .createdAt(dto.getCreatedAt())
                .updatedAt(dto.getUpdatedAt())
                .tags(dto.getTags())
                .isHome(dto.getIsHome())
                .bannerImage(dto.getBannerImage())
                .locationId(dto.getLocationId())
                .propertyStatus(dto.getPropertyStatus())
                .map(dto.getMap())
                .propertyView(dto.getPropertyView())
                .instantBookingButton(dto.getInstantBookingButton())
                .template(dto.getTemplate())
                .ordering(dto.getOrdering())
                .formType(dto.getFormType())
                .level(dto.getLevel())
                .lecture(dto.getLecture())
                .duration(dto.getDuration())
                .access(dto.getAccess())
                .certificate(dto.getCertificate())
                .recourse(dto.getRecourse())
                .icon(dto.getIcon())
                .isHeaderFooter(dto.getIsHeaderFooter())
                .totalEnroll(dto.getTotalEnroll())
                .isPopular(dto.getIsPopular())
                .rentalAggrementAttachment(dto.getRentalAggrementAttachment())
                .bannerHeading(dto.getBannerHeading())
                .bannerLink(dto.getBannerLink())
                .bannerText(dto.getBannerText())
                .googleRate(dto.getGoogleRate())
                .sulekhaRate(dto.getSulekhaRate())
                .urbanRate(dto.getUrbanRate())
                .jdRate(dto.getJdRate())
                .facebookRate(dto.getFacebookRate())
                .build();
    }

    public PropertyDTO toDto(Property entity) {
        PropertyDTO dto = new PropertyDTO();
        dto.setId(entity.getId());
        dto.setName(entity.getName());
        dto.setSeoUrl(entity.getSeoUrl());
        dto.setHeading(entity.getHeading());
        dto.setPrice(entity.getPrice());
        dto.setAddress(entity.getAddress());
        dto.setMobile(entity.getMobile());
        dto.setEmail(entity.getEmail());
        dto.setWebsite(entity.getWebsite());
        dto.setShortDescription(entity.getShortDescription());
        dto.setLongDescription(entity.getLongDescription());
        dto.setDescription(entity.getDescription());
        dto.setCancellationPolicy(entity.getCancellationPolicy());
        dto.setBookingPolicy(entity.getBookingPolicy());
        dto.setNotes(entity.getNotes());
        dto.setFeatureImage(entity.getFeatureImage());
        dto.setStatus(entity.getStatus());
        dto.setMetaTitle(entity.getMetaTitle());
        dto.setMetaKeywords(entity.getMetaKeywords());
        dto.setMetaDescription(entity.getMetaDescription());
        dto.setHeaderSection(entity.getHeaderSection());
        dto.setFooterSection(entity.getFooterSection());
        dto.setCreatedAt(entity.getCreatedAt());
        dto.setUpdatedAt(entity.getUpdatedAt());
        dto.setTags(entity.getTags());
        dto.setIsHome(entity.getIsHome());
        dto.setBannerImage(entity.getBannerImage());
        dto.setLocationId(entity.getLocationId());
        dto.setPropertyStatus(entity.getPropertyStatus());
        dto.setMap(entity.getMap());
        dto.setPropertyView(entity.getPropertyView());
        dto.setInstantBookingButton(entity.getInstantBookingButton());
        dto.setTemplate(entity.getTemplate());
        dto.setOrdering(entity.getOrdering());
        dto.setFormType(entity.getFormType());
        dto.setLevel(entity.getLevel());
        dto.setLecture(entity.getLecture());
        dto.setDuration(entity.getDuration());
        dto.setAccess(entity.getAccess());
        dto.setCertificate(entity.getCertificate());
        dto.setRecourse(entity.getRecourse());
        dto.setIcon(entity.getIcon());
        dto.setIsHeaderFooter(entity.getIsHeaderFooter());
        dto.setTotalEnroll(entity.getTotalEnroll());
        dto.setIsPopular(entity.getIsPopular());
        dto.setRentalAggrementAttachment(entity.getRentalAggrementAttachment());
        dto.setBannerHeading(entity.getBannerHeading());
        dto.setBannerLink(entity.getBannerLink());
        dto.setBannerText(entity.getBannerText());
        dto.setGoogleRate(entity.getGoogleRate());
        dto.setSulekhaRate(entity.getSulekhaRate());
        dto.setUrbanRate(entity.getUrbanRate());
        dto.setJdRate(entity.getJdRate());
        dto.setFacebookRate(entity.getFacebookRate());
        return dto;
    }
}
