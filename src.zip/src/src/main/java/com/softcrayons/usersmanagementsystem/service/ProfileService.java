package com.softcrayons.usersmanagementsystem.service;
import org.springframework.web.multipart.MultipartFile;
import com.softcrayons.usersmanagementsystem.dto.ProfileDto;
import java.util.List;


public interface ProfileService {
    ProfileDto createProfile(ProfileDto dto, MultipartFile profileImage, MultipartFile logo);
    ProfileDto updateProfile(Long id, ProfileDto dto, MultipartFile profileImage, MultipartFile logo);
    List<ProfileDto> getAllProfiles();
    ProfileDto getProfileById(Long id);
    void deleteProfile(Long id);
}
