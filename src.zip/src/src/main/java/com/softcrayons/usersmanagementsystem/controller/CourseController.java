package com.softcrayons.usersmanagementsystem.controller;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import java.io.File;
import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import com.softcrayons.usersmanagementsystem.dto.PropertyDTO;
import com.softcrayons.usersmanagementsystem.dto.PropertyTitlesDto;
import com.softcrayons.usersmanagementsystem.entity.Property;
import com.softcrayons.usersmanagementsystem.entity.Services;
import com.softcrayons.usersmanagementsystem.exception.PropertyNotFoundException;
import com.softcrayons.usersmanagementsystem.exception.ResourceNotFoundException;
import com.softcrayons.usersmanagementsystem.service.CourseCategroiesManagementService;
import com.softcrayons.usersmanagementsystem.service.PropertyService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestPart;

@RestController
public class CourseController {
    @Autowired
    private CourseCategroiesManagementService courseCategroiesManagementService;
 
    @Autowired
    private PropertyService propertyService;

    @Cacheable("courseByUrl")
    @GetMapping("/public/is_exist_url/{url}")
    public ResponseEntity<Boolean> isUrlExist(@PathVariable String url) {
        boolean exists = propertyService.isUrlExists(url);
        return ResponseEntity.ok(exists);
    }

    @GetMapping("/public/services")
    @Cacheable("servicesList")
    public ResponseEntity<List<Services>> getAllServicesName() {
        List<Services> services = courseCategroiesManagementService.getAll();
        if (services.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(services);
    }

    @GetMapping("/public/course_categories/all")
    @Cacheable("courseList")
    public ResponseEntity<List<Services>> getAllCourses() {
        List<Services> courses = courseCategroiesManagementService.getAll();
        if (courses.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(courses);
    }

    @GetMapping("/public/properties")
       @Cacheable("propertiesList")
    public ResponseEntity<List<PropertyTitlesDto>> getAllPropertyName() {
        List<PropertyTitlesDto> properties = propertyService.getAllList();
        if (properties.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(properties);
    }

    @GetMapping("/public/allPages")
    @Cacheable("pageList")
    public ResponseEntity<List<Property>> getAllPages() {
        List<Property> properties = propertyService.getAll();
        if (properties.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(properties);
    }

    @GetMapping("/public/page/{seo_url}")
       @Cacheable("pageByUrl")
    public ResponseEntity<PropertyDTO> getPage(@PathVariable("seo_url") String seoUrl) {
        try {
            PropertyDTO page = propertyService.getPage(seoUrl);
            return ResponseEntity.ok(page);
        } catch (PropertyNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }

    @PostMapping(value = "/auth/page/add_property", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @CacheEvict(value = {"pageByUrl", "pageList", "propertiesList"}, allEntries = true)
    public ResponseEntity<?> createProperty(
            @RequestPart("property") String property,
            @RequestPart(value = "featureImage", required = false) MultipartFile featureImage,
            @RequestPart(value = "bannerImage", required = false) MultipartFile bannerImage,
            @RequestPart(value = "icon", required = false) MultipartFile icon,
            @RequestPart(value = "rentalAggrementAttachment", required = false) MultipartFile rentalAggrementAttachment) {
    
        try {
            PropertyDTO savedProperty = propertyService.saveProperty(property, featureImage, bannerImage, icon,
                    rentalAggrementAttachment);
            return new ResponseEntity<>(savedProperty, HttpStatus.CREATED);
        } catch (IOException e) {
            return new ResponseEntity<>("Failed to upload files: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping(value = "/auth/page/update_property/{seoUrl}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
     @CacheEvict(value = {"pageByUrl", "pageList", "propertiesList"}, key = "#seoUrl")
    public ResponseEntity<?> updateProperty(
            @PathVariable("seoUrl") String seoUrl,
            @RequestPart("property") String property,
            @RequestPart(value = "featureImage", required = false) MultipartFile featureImage,
            @RequestPart(value = "bannerImage", required = false) MultipartFile bannerImage,
            @RequestPart(value = "icon", required = false) MultipartFile icon,
            @RequestPart(value = "rentalAggrementAttachment", required = false) MultipartFile rentalAggrementAttachment) {
    
        try {
            PropertyDTO updatedProperty = propertyService.updatePropertyBySeoUrl(seoUrl, property, featureImage,
                    bannerImage, icon, rentalAggrementAttachment);
            return new ResponseEntity<>(updatedProperty, HttpStatus.OK);
        } catch (IOException e) {
            return new ResponseEntity<>("Failed to update property files: " + e.getMessage(),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (ResourceNotFoundException e) {
            return new ResponseEntity<>("Property not found: " + e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }



  
    @GetMapping("/public/file/{fileName:.+}")
    public ResponseEntity<Resource> getFile(@PathVariable String fileName) throws IOException {

        String decodedFileName = URLDecoder.decode(fileName, StandardCharsets.UTF_8);
        // String filePathStr = "uploads/properties/" + decodedFileName;
        String filePathStr = new File(".").getCanonicalPath() + "/uploads/properties/" + decodedFileName;
        File file = new File(filePathStr);
        if (!file.exists()) {
            return ResponseEntity.notFound().build();
        }
        Path path = file.toPath();
        String contentType = Files.probeContentType(path);
        // Fallback for common types
        if (contentType == null) {
            if (fileName.endsWith(".png"))
                contentType = "image/png";
            else if (fileName.endsWith(".jpg") || fileName.endsWith(".jpeg"))
                contentType = "image/jpeg";
            else if (fileName.endsWith(".webp"))
                contentType = "image/webp";
            else if (fileName.endsWith(".pdf"))
                contentType = "application/pdf";
            else
                contentType = "application/octet-stream";
        }

        FileSystemResource resource = new FileSystemResource(file);
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(contentType))
                .body(resource);
    }

}
