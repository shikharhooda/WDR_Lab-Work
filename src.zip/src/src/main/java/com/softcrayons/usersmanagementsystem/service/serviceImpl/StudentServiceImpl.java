package com.softcrayons.usersmanagementsystem.service.serviceImpl;

import com.softcrayons.usersmanagementsystem.dto.student.StudentDto;
import com.softcrayons.usersmanagementsystem.entity.Student;
import com.softcrayons.usersmanagementsystem.repository.StudentRepository;
import com.softcrayons.usersmanagementsystem.service.StudentService;
import com.softcrayons.usersmanagementsystem.util.ReportService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private final ReportService reportService;
    @Autowired
    private StudentRepository repository;

    StudentServiceImpl(ReportService reportService) {
        this.reportService = reportService;
    }

    private StudentDto convertToDto(Student student) {
        StudentDto dto = new StudentDto();
        BeanUtils.copyProperties(student, dto);

        return dto;
    }

    private Student convertToEntity(StudentDto dto) {
        Student student = new Student();
        BeanUtils.copyProperties(dto, student);
        return student;
    }

    @Override
    public StudentDto createStudent(StudentDto studentDto) {
        Student student = convertToEntity(studentDto);
        Student savedStudent = repository.save(student);

        try {
            reportService.generateAndSendReport(savedStudent);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return convertToDto(savedStudent);
    }

    @Override
    public StudentDto updateStudentById(Integer id, StudentDto dto) {
        Student student = repository.findById(id).orElseThrow();
        BeanUtils.copyProperties(dto, student, "id");
        return convertToDto(repository.save(student));
    }

    @Override
    public StudentDto getStudentById(Integer id) {
        Student student = repository.findById(id).orElseThrow();
        return convertToDto(student);
    }

    @Override
    public List<StudentDto> getAllStudents() {
        return repository.findAll()
                .stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Override
    public void deleteStudentById(Integer id) {
        repository.deleteById(id);
    }

    @Override
    public StudentDto getStudentByStudentId(String studentId) {
        return repository.findByStudentId(studentId)
                .map(this::convertToDto)
                .orElse(null);
    }

    @Override
    public StudentDto updateStudentByStudentId(String studentId, StudentDto dto) {
        Student student = repository.findByStudentId(studentId).orElseThrow();
        BeanUtils.copyProperties(dto, student, "id");
        return convertToDto(repository.save(student));
    }

    @Override
    public void deleteStudentByStudentId(String studentId) {
        repository.deleteByStudentId(studentId);
    }

    @Override
    public StudentDto getStudentByEmail(String email) {
        return convertToDto(repository.findByEmail(email).orElseThrow());
    }

    @Override
    public StudentDto updateStudentByEmail(String email, StudentDto dto) {
        Student student = repository.findByEmail(email).orElseThrow();
        BeanUtils.copyProperties(dto, student, "id");
        return convertToDto(repository.save(student));
    }

    @Override
    public void deleteStudentByEmail(String email) {
        repository.deleteByEmail(email);
    }
}
