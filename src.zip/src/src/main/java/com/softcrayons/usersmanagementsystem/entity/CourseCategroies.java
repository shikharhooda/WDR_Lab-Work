package com.softcrayons.usersmanagementsystem.entity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Table(name="career_categories")
public class CourseCategroies{
      @Id
      @GeneratedValue(strategy=GenerationType.IDENTITY)
      private int  id;
      private  String title;
      private String seo_url;
      private String  image;

      @Column(name = "shortDescription")
      private String shortDescription;
      private String benefits;

      @Column(name="longDescription")
      private String longDescription;

      private  String isHome="true";
      private String publish;
      private String isParent;
      private String meta_title;
      private String meta_keywords;
      private  String meta_description;
      private  String  bannerImage;
      private Integer  ordering;
      private String templete;
      private String  created_at;
      private  String  updated_at;
      private  String description;
      private String  head_section;
      private String icon;
      private String  form_heading;
      private String  form_paragraph;
      private  String  infographics; 
}
