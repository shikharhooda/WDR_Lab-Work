package com.softcrayons.usersmanagementsystem.dto;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
@Builder
public class PropertyTitlesDto {

    private Long id;
    private String name;
    private String seoUrl;
    private Integer locationId;
    private String   isPopular;
    private String bannerImage;
    private String featureImage;
    private String isHome;
    private String  level;
    private String duration;
    private String lecture;
    private Integer  totalEnroll;
    private String  instant_booking_button;
      
    public PropertyTitlesDto(Long id, String name, String  seoUrl,  Integer locationId, String isPopular, String  bannerImage, String featureImage, String isHome, String  duration,  String lecture, String lavel, Integer totalEnroll, String  instant_booking_button) {
        this.id = id;
        this.name = name;
        this.seoUrl  = seoUrl;
        this.locationId  = locationId;
        this.isPopular= isPopular;
        this.bannerImage  =  bannerImage;
        this.featureImage  =  featureImage;
        this.isHome = isHome;
        this.level= lavel;
        this.lecture= lecture;
        this.duration  = duration;
        this.totalEnroll= totalEnroll;
        this.instant_booking_button  =  instant_booking_button;
    }
}
