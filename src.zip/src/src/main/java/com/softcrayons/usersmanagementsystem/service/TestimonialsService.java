package com.softcrayons.usersmanagementsystem.service;

import com.softcrayons.usersmanagementsystem.dto.TestimonialsDto;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface TestimonialsService {
    TestimonialsDto create(TestimonialsDto dto, MultipartFile profileImage, MultipartFile bannerImage) throws IOException;
    TestimonialsDto update(Long id, TestimonialsDto dto, MultipartFile profileImage, MultipartFile bannerImage) throws IOException;
    TestimonialsDto get(Long id);
    List<TestimonialsDto> getAll();
    void delete(Long id);
}
