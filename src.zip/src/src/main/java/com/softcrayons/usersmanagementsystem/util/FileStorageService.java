package com.softcrayons.usersmanagementsystem.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

@Service
public class FileStorageService {

    @Value("${file.upload-dir}")
    private String uploadDir;

    public String storeFile(String fileDataString, String fileType) throws IOException {
        if (fileDataString == null || fileDataString.isEmpty()) {
            return null;
        }
    
        // Create the directory if it doesn't exist
        String subDirectory = fileType.equals("document") ? "documents" : "images";
        Path dirPath = Paths.get(uploadDir, subDirectory);
        if (!Files.exists(dirPath)) {
            Files.createDirectories(dirPath);
        }
    
        // Generate unique filename to avoid conflicts
        String uniqueFilename = UUID.randomUUID().toString() + ".dat";
        
        // Save the file to the specified location
        Path targetLocation = dirPath.resolve(uniqueFilename);
        Files.write(targetLocation, fileDataString.getBytes());
    
        // Return the relative path for storage in database
        return subDirectory + "/" + uniqueFilename;
    }

    // Method to handle MultipartFile if needed for other scenarios
    public String storeMultipartFile(MultipartFile file, String subDirectory) throws IOException {
        if (file == null || file.isEmpty()) {
            return null;
        }

        // Create the directory if it doesn't exist
        Path dirPath = Paths.get(uploadDir);
        if (!Files.exists(dirPath)) {
            Files.createDirectories(dirPath);
        }

        // Generate unique filename to avoid conflicts
        String originalFilename = file.getOriginalFilename();
        String fileExtension = "";
        if (originalFilename != null && originalFilename.contains(".")) {
            fileExtension = originalFilename.substring(originalFilename.lastIndexOf("."));
        }
        String uniqueFilename = UUID.randomUUID().toString() + fileExtension;
        
        // Save the file to the specified location
        Path targetLocation = dirPath.resolve(uniqueFilename);
        Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);

        // Return the relative path for storage in database
        return subDirectory + "/" + uniqueFilename;
    }
}