package com.softcrayons.usersmanagementsystem.service.serviceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.softcrayons.usersmanagementsystem.dto.ProfileDto;
import com.softcrayons.usersmanagementsystem.entity.Profile;
import com.softcrayons.usersmanagementsystem.repository.ProfileRepository;
import com.softcrayons.usersmanagementsystem.service.ProfileService;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ProfileServiceImpl implements ProfileService {

    private final ProfileRepository profileRepository;

      @Value("${file.upload-dir}")
    private String uploadDir;

    private String saveFile(MultipartFile file, String folder) {
        if (file == null || file.isEmpty()) return null;
        try {
            Path directory = Paths.get(uploadDir, folder);
            if (!Files.exists(directory)) {
                Files.createDirectories(directory);
            }
            String filename = System.currentTimeMillis() + "_" + file.getOriginalFilename();
            Path filePath = directory.resolve(filename);
            file.transferTo(filePath.toFile());
            return "/uploads/properties/" + filename;
        } catch (IOException e) {
            throw new RuntimeException("Failed to store file", e);
        }
    }

    private ProfileDto mapToDto(Profile profile) {
        return ProfileDto.builder()
                .id(profile.getId())
                .name(profile.getName())
                .description(profile.getDescription())
                .position(profile.getPosition())
                .profileImageUrl(profile.getProfileImagePath())
                .logoUrl(profile.getLogoPath())
                .build();
    }

    @Override
    public ProfileDto createProfile(ProfileDto dto, MultipartFile profileImage, MultipartFile logo) {
        Profile profile = Profile.builder()
                .name(dto.getName())
                .description(dto.getDescription())
                .position(dto.getPosition())
                .profileImagePath(saveFile(profileImage, "profile"))
                .logoPath(saveFile(logo, "logo"))
                .build();
        return mapToDto(profileRepository.save(profile));
    }

    @Override
    public ProfileDto updateProfile(Long id, ProfileDto dto, MultipartFile profileImage, MultipartFile logo) {
        Profile profile = profileRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Profile not found"));
        profile.setName(dto.getName());
        profile.setDescription(dto.getDescription());
        profile.setPosition(dto.getPosition());
        if (profileImage != null && !profileImage.isEmpty()) {
            profile.setProfileImagePath(saveFile(profileImage, "profile"));
        }
        if (logo != null && !logo.isEmpty()) {
            profile.setLogoPath(saveFile(logo, "logo"));
        }
        return mapToDto(profileRepository.save(profile));
    }

    @Override
    public List<ProfileDto> getAllProfiles() {
        return profileRepository.findAll().stream().map(this::mapToDto).collect(Collectors.toList());
    }

    @Override
    public ProfileDto getProfileById(Long id) {
        return profileRepository.findById(id).map(this::mapToDto)
                .orElseThrow(() -> new RuntimeException("Profile not found"));
    }

    @Override
    public void deleteProfile(Long id) {
        profileRepository.deleteById(id);
    }
}
