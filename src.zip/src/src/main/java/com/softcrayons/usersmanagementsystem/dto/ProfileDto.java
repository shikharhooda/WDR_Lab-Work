package com.softcrayons.usersmanagementsystem.dto;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProfileDto {
    private Long id;
    private String name;
    private String description;
    private String position;
    private String profileImageUrl;
    private String logoUrl;
}
