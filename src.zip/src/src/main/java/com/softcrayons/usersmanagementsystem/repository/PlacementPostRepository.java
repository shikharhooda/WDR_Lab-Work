package com.softcrayons.usersmanagementsystem.repository;



import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.softcrayons.usersmanagementsystem.entity.PlacementPost;



@Repository
public interface PlacementPostRepository extends JpaRepository<PlacementPost, Long>, JpaSpecificationExecutor<PlacementPost> {

//     Optional<PlacementPost> findBySeoUrl(String seoUrl);

//     boolean existsBySeoUrl(String seoUrl);

//     boolean existsBySeoUrlAndIdNot(String seoUrl, Long id);

    Page<PlacementPost> findByStatus(String status, Pageable pageable);

    Page<PlacementPost> findByTrendingTrue(Pageable pageable);

    Page<PlacementPost> findByPopularTrue(Pageable pageable);

    Page<PlacementPost> findByLatestTrue(Pageable pageable);

    Page<PlacementPost> findByLocationId(String locationId, Pageable pageable);

    @Query("SELECT d FROM PlacementPost d WHERE " +
           "LOWER(d.name) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(d.title) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(d.description) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    Page<PlacementPost> searchByKeyword(@Param("keyword") String keyword, Pageable pageable);

    @Query("SELECT d FROM PlacementPost d WHERE d.status = :status AND " +
           "(LOWER(d.name) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(d.title) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    Page<PlacementPost> findByStatusAndKeyword(@Param("status") String status, 
                                        @Param("keyword") String keyword, 
                                        Pageable pageable);
}