package com.softcrayons.usersmanagementsystem.dto.banner;

import io.micrometer.common.lang.NonNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BannerDto {
        private Integer  id;
        private String name;
        private String   createdAt;
        private String updatedAt;
        //  Add with  pipe  ||  for more than one;
        @NonNull
        private String  bannerImage;
        private String  description;
        private String  title;
        private String  information;
        
}
