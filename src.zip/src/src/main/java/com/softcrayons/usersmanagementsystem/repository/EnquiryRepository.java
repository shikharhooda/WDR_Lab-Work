package com.softcrayons.usersmanagementsystem.repository;



import org.springframework.data.jpa.repository.JpaRepository;

import com.softcrayons.usersmanagementsystem.entity.Enquiry;

public interface EnquiryRepository extends JpaRepository<Enquiry, Long> {
}
