package com.softcrayons.usersmanagementsystem.service.serviceImpl;
import com.softcrayons.usersmanagementsystem.dto.PlacementDto;
import com.softcrayons.usersmanagementsystem.entity.Placement;
import com.softcrayons.usersmanagementsystem.exception.ResourceNotFoundException;
import com.softcrayons.usersmanagementsystem.repository.PlacementRepository;
import com.softcrayons.usersmanagementsystem.service.PlacementService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class PlacementServiceImpl implements PlacementService {

    private final PlacementRepository placementRepository;

    @Value("${file.upload-dir}")
    private String UPLOAD_DIR;

    public PlacementServiceImpl(PlacementRepository placementRepository) {
        this.placementRepository = placementRepository;
    }

    @Override
    public PlacementDto createPlacement(PlacementDto dto, MultipartFile image , MultipartFile logo ) {
        Placement placement = mapToEntity(dto);

        placement.setImage(saveFile(image));
        placement.setCompanyLogo(saveFile(logo));

        Placement saved = placementRepository.save(placement);
        return mapToDto(saved);
    }

    @Override
    public PlacementDto updatePlacement(Long id, PlacementDto dto, MultipartFile image , MultipartFile logo) {
        Placement placement = placementRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("placement not found"));

        placement.setName(dto.getName());
        placement.setShortDescription(dto.getShortDescription());
        placement.setLongDescription(dto.getLongDescription());
        placement.setMetaDescription(dto.getMetaDescription());
        placement.setMetaKeywords(dto.getMetaKeywords());
        placement.setMetaTitle(dto.getMetaTitle());
        placement.setPublished(dto.getPublished());

        if (image != null) {
            placement.setImage(saveFile(image));
        }
        if (logo!= null) {
            placement.setCompanyLogo(UPLOAD_DIR);
            saveFile(logo);
        }

        return mapToDto(placementRepository.save(placement));
    }

    @Override
    public void deletePlacement(Long id) {
        placementRepository.deleteById(id);
    }

    @Override
    public PlacementDto getPlacementById(Long id) {
        return placementRepository.findById(id)
                .map(this::mapToDto)
                .orElseThrow(() -> new ResourceNotFoundException("placement Not Found"));
    }

    @Override
    public List<PlacementDto> getAllPlacements() {
        return placementRepository.findAll().stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    private String saveFile(MultipartFile file) {
        if (file == null || file.isEmpty())
            return null;

        try {
            // Absolute path of uploads/properties
            String uploadDir = System.getProperty("user.dir") + "/uploads/properties";

            // Create directory if not exists
            Files.createDirectories(Paths.get(uploadDir));

            // Unique file name
            String filename = UUID.randomUUID() + "_" + file.getOriginalFilename();
            String fullPath = uploadDir + File.separator + filename;

            // Save file
            file.transferTo(new File(fullPath));

            // Return relative path for frontend
            return "/uploads/properties/" + filename;

        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to store file: " + e.getMessage());
        }
    }

    private Placement mapToEntity(PlacementDto dto) {

        System.out.println( dto.getName() + "--------->"+ dto.getPublished());
        return Placement.builder()
                .name(dto.getName())
                .published(dto.getPublished())
                .longDescription(dto.getLongDescription())
                .shortDescription(dto.getShortDescription())
                .metaDescription(dto.getMetaDescription())
                .metaKeywords(dto.getMetaKeywords())
                .metaTitle(dto.getMetaTitle())
                .companyLink(dto.getCompanyLink())
                .build();
    }

    private PlacementDto mapToDto(Placement placement) {
        return PlacementDto.builder()
                .id(placement.getId())
                .name(placement.getName())
                .published(placement.getPublished())
                .longDescription(placement.getLongDescription())
                .shortDescription(placement.getShortDescription())
                .metaDescription(placement.getMetaDescription())
                .metaKeywords(placement.getMetaKeywords())
                .metaTitle(placement.getMetaTitle())
                .createdAt(placement.getCreatedAt())
                .updatedAt(placement.getUpdatedAt())
                .image(placement.getImage())
                .companyLogo(placement.getCompanyLogo())
                .companyLink(placement.getCompanyLink())
                .build();
    }

    @Override
    public Page<PlacementDto> getPlacementsPaged(int page, int size) {
        PageRequest pageable = PageRequest.of(page, size);
        Page<Placement> placementPage = placementRepository.findAll(pageable);

        List<PlacementDto> placementDtos = placementPage.getContent()
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());

        return new PageImpl<>(placementDtos, pageable, placementPage.getTotalElements());
    }
}
