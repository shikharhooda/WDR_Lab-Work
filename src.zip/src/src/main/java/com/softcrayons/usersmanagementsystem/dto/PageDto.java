package com.softcrayons.usersmanagementsystem.dto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
public class PageDto {

    private Long id;
    private String name;
    private String seoUrl;
    private String heading;
    private String price;
    // private String address;
    // private String mobile;
    // private String email;
    // private String website;
    // private String shortDescription;
    private String longDescription;
    private String description;
    // private String cancellationPolicy;
    // private String bookingPolicy;
    private String notes;
    private String featureImage;
    private String status;

    private String metaTitle;
    private String metaKeywords;
    private String metaDescription;

    //private String headerSection;
    //private String footerSection;
    //private Timestamp createdAt;
    //private Timestamp updatedAt;
    private String tags;
    private String isHome;

    private String bannerImage;
    private Integer locationId;

    //private String propertyStatus;
    //private String map;

    private String propertyView;

    private String instantBookingButton;
    private String template;
    
    // private Integer ordering;
    // private String formType;

    private String level;
    private String lecture;
    private String duration;
    private String access;
    private String certificate;
    private String recourse;  
    private String icon;

    //private String isHeaderFooter;

    private Integer totalEnroll;
    private String isPopular;
    private String rentalAggrementAttachment;
    private String bannerHeading;

    //private String bannerLink;
    private String bannerText;
    private String googleRate;
    private String sulekhaRate;
    private String urbanRate;
    private String jdRate;
    private String facebookRate;
    private String isHeaderFooter;

    public PageDto(Long id, String name, String  seoUrl, String heading,  String longDescription, String  description, String notes, String featureImage, String status,
      String  metaTitle, String metaKeywords, String metaDescription, String  bannerImage, Integer locationId, String  propertyView, String instantBookingButton,String template, 
      String  level, String  lecture, String duration , String access, String  certificate,  String  resource ,  String  icon, Integer totalEnroll,
      String isPopular, String rentalAggrementAttachment, String bannerHeading, String bannerText, String googleRate,  String sulekhaRate, String urbanRate, String jdRate, String facebook,    String isHeaderFooter, String price, String tags, String isHome) {
        this.id = id;
        this.name = name;
        this.seoUrl  = seoUrl;
        this.heading =   heading;
     
        this.longDescription =  longDescription;
        this.description =  description;
        this.notes = notes;
        this.featureImage = featureImage;
        this.status  = status;

        this.metaTitle  = metaTitle;
        this.metaKeywords =  metaKeywords;
        this.metaDescription = metaDescription;

        this.bannerImage  =  bannerImage;
        this.locationId  = locationId;
        this.propertyView  = propertyView;

        this.instantBookingButton  =  instantBookingButton;
        this.template = template;

        this.level   = level;
        this.lecture  = lecture;
        this.duration  = duration;
        this.access  = access;
        this.certificate = certificate;
        this.recourse  = resource;
        this.icon  =  icon;

        this.totalEnroll=totalEnroll;
        this.isPopular=isPopular;
        this.rentalAggrementAttachment=rentalAggrementAttachment;
        this.bannerHeading = bannerHeading;

        this.bannerText=  bannerText;
        this.googleRate = googleRate;
        this.sulekhaRate =sulekhaRate;
        this.urbanRate = urbanRate;
        this.jdRate = jdRate;
        this.facebookRate = facebook;
        this.isHeaderFooter = isHeaderFooter;
        this.price  = price;
        this.tags= tags;
        this.isHome= isHome;
    }
}
