package com.softcrayons.usersmanagementsystem.entity;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Enquiry {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String contact;

    private String alternateContact;
    private String course;
    private String education;
    private String remarks;
    private String leadStatus;
    private String email;
    private String address;
    private String assignedTo;
    private LocalDate assignedDate;
    private String duration;

    @Column(updatable = false)
    private LocalDate enquiryDate;

    private String working;
    private String workingRemarks;
    private String availabilityDetails;

    @PrePersist
    public void prePersist() {
        this.enquiryDate = LocalDate.now();
    }
}
