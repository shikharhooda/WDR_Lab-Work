package com.softcrayons.usersmanagementsystem.service.serviceImpl;

import com.softcrayons.usersmanagementsystem.dto.blos.BlogDto;
import com.softcrayons.usersmanagementsystem.entity.Blog;
import com.softcrayons.usersmanagementsystem.exception.ResourceNotFoundException;
import com.softcrayons.usersmanagementsystem.repository.BlogRepository;
import com.softcrayons.usersmanagementsystem.service.BlogService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class BlogServiceImpl implements BlogService {

    private final BlogRepository blogRepository;

    @Value("${file.upload-dir}")
    private String UPLOAD_DIR;

    public BlogServiceImpl(BlogRepository blogRepository) {
        this.blogRepository = blogRepository;
    }

    @Override
    public BlogDto createBlog(BlogDto dto) {
        Blog blog = mapToEntity(dto);

        blog.setImage(saveFile(dto.getImageFile()));
        blog.setFeatureImage(saveFile(dto.getFeatureImageFile()));

        Blog saved = blogRepository.save(blog);
        return mapToDto(saved);
    }

    @Override
    public BlogDto updateBlog(String url, BlogDto dto) {
        Blog blog = blogRepository.findBySeoUrl(url)
                .orElseThrow(() -> new RuntimeException("Blog not found"));

        blog.setTitle(dto.getTitle());
        blog.setSeoUrl(dto.getSeoUrl());
        blog.setShortDescription(dto.getShortDescription());
        blog.setLongDescription(dto.getLongDescription());
        blog.setMetaDescription(dto.getMetaDescription());
        blog.setMetaKeywords(dto.getMetaKeywords());
        blog.setMetaTitle(dto.getMetaTitle());
        blog.setStatus(dto.getStatus());
        blog.setPublish(dto.getPublish());
        blog.setBlogCategoryId(dto.getBlogCategoryId());
        blog.setAgentId(dto.getAgentId());
    //  System.out.println(dto.getFeatureImage()  + "---------------->");
        if (dto.getImageFile() != null  ) {
            blog.setImage(saveFile(dto.getImageFile()));
        }
        if (dto.getFeatureImageFile() != null) {
            blog.setFeatureImage(saveFile(dto.getFeatureImageFile()));
        }

        return mapToDto(blogRepository.save(blog));
    }

    @Override
    public void deleteBlog(Long id) {
        blogRepository.deleteById(id);
    }

    @Override
    public BlogDto getBlog(String seoUrl) {
        return blogRepository.findBySeoUrl(seoUrl)
                .map(this::mapToDto)
                .orElseThrow(() -> new ResourceNotFoundException("Blog Not Found"));
    }

    @Override
    public List<BlogDto> getAllBlogs() {
        return blogRepository.findAll().stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }



    private String saveFile(MultipartFile file) {
    if (file == null || file.isEmpty()) return null;

    try {
        // Absolute path of uploads/properties
        String uploadDir = System.getProperty("user.dir") + "/uploads/properties";

        // Create directory if not exists
        Files.createDirectories(Paths.get(uploadDir));

        // Unique file name
        String filename = UUID.randomUUID() + "_" + file.getOriginalFilename();
        String fullPath = uploadDir + File.separator + filename;

        // Save file
        file.transferTo(new File(fullPath));

        // Return relative path for frontend
        return "/uploads/properties/" + filename;

    } catch (IOException e) {
        e.printStackTrace();
        throw new RuntimeException("Failed to store file: " + e.getMessage());
    }
}


    private Blog mapToEntity(BlogDto dto) {
        return Blog.builder()
                .title(dto.getTitle())
                .seoUrl(dto.getSeoUrl())
                .publish(dto.getPublish())
                .longDescription(dto.getLongDescription())
                .shortDescription(dto.getShortDescription())
                .metaDescription(dto.getMetaDescription())
                .metaKeywords(dto.getMetaKeywords())
                .metaTitle(dto.getMetaTitle())
                .blogCategoryId(dto.getBlogCategoryId())
                .agentId(dto.getAgentId())
                .status(dto.getStatus())
                .build();
    }

    private BlogDto mapToDto(Blog blog) {
        return BlogDto.builder()
                .id(blog.getId())
                .title(blog.getTitle())
                .seoUrl(blog.getSeoUrl())
                .publish(blog.getPublish())
                .longDescription(blog.getLongDescription())
                .shortDescription(blog.getShortDescription())
                .metaDescription(blog.getMetaDescription())
                .metaKeywords(blog.getMetaKeywords())
                .metaTitle(blog.getMetaTitle())
                .blogCategoryId(blog.getBlogCategoryId())
                .agentId(blog.getAgentId())
                .status(blog.getStatus())
                .createdAt(blog.getCreatedAt())
                .updatedAt(blog.getUpdatedAt())
                .image(blog.getImage())
                .featureImage(blog.getFeatureImage())
                .build();
    }

public boolean isAvailable(String url) {
    Optional<Blog> blog = blogRepository.findBySeoUrl(url);
    return blog.isPresent(); 
}
}
