package com.softcrayons.usersmanagementsystem.entity;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "certificate_enquiries")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CertificateEnquiry{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private String contact;

    private String email;

    private String course;

    private String trainer;

    private String message;

    private String address;
   
}
