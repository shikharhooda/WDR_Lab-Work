package com.softcrayons.usersmanagementsystem.dto;

import lombok.Data;

@Data
public class TestimonialsDto {
    private Long id;
    private String name;
    private String education;
    private String course;
    private String company;
    private String designation;
    private int rating;
    private String review;
    private String facebookLink;
    private String linkdinLink;
    private String email;
    private String contact;
    private String videoUrl;
}
