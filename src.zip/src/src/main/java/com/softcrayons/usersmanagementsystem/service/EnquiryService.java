package com.softcrayons.usersmanagementsystem.service;
import java.util.List;

import com.softcrayons.usersmanagementsystem.dto.enquiry.EnquiryDto;

public interface EnquiryService {
    EnquiryDto saveEnquiry(EnquiryDto dto);
    List<EnquiryDto> getAllEnquiries();
    EnquiryDto getEnquiryById(Long id);
    EnquiryDto updateEnquiry(Long id, EnquiryDto dto);
    void deleteEnquiry(Long id);
}
