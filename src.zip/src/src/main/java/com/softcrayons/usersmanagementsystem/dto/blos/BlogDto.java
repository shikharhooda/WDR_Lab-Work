package com.softcrayons.usersmanagementsystem.dto.blos;


import lombok.*;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BlogDto {
    private Long id;
    private String title;
    private String seoUrl;
    private String publish;
    private String longDescription;
    private String shortDescription;
    private String metaDescription;
    private String metaKeywords;
    private String metaTitle;
    private String blogCategoryId;
    private Integer agentId;
    private String status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    private MultipartFile imageFile;
    private MultipartFile featureImageFile;

    private String image;
    private String featureImage;
}
