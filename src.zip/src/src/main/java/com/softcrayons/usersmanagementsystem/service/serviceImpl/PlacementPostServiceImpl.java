package com.softcrayons.usersmanagementsystem.service.serviceImpl;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.softcrayons.usersmanagementsystem.dto.placementpost.request.PlacementPostCreateRequest;
import com.softcrayons.usersmanagementsystem.dto.placementpost.request.PlacementPostUpdateRequest;
import com.softcrayons.usersmanagementsystem.dto.placementpost.response.PageResponse;
import com.softcrayons.usersmanagementsystem.dto.placementpost.response.PlacementPostResponse;
import com.softcrayons.usersmanagementsystem.entity.PlacementPost;
import com.softcrayons.usersmanagementsystem.exception.ResourceNotFoundException;
import com.softcrayons.usersmanagementsystem.mapper.PlacementPostMapper;
import com.softcrayons.usersmanagementsystem.repository.PlacementPostRepository;
import com.softcrayons.usersmanagementsystem.service.FileStorageService;
import com.softcrayons.usersmanagementsystem.service.PlacementPostService;

// Service Paackage FIleStorage is vbeing used here

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional(readOnly = true)
public class PlacementPostServiceImpl implements PlacementPostService {

    private final PlacementPostRepository domainRepository;
    private final PlacementPostMapper domainMapper;
    private final FileStorageService fileStorageService;

    @Override
    @Transactional
    public PlacementPostResponse createDomain(PlacementPostCreateRequest request) {
        log.info("Creating new domain with name: {}", request.getName());

        // if (request.getSeoUrl() != null && domainRepository.existsBySeoUrl(request.getSeoUrl())) {
        //     throw new IllegalArgumentException("Domain with SEO URL '" + request.getSeoUrl() + "' already exists");
        // }

        PlacementPost domain = domainMapper.toEntity(request);
        PlacementPost savedDomain = domainRepository.save(domain);

        log.info("Domain created successfully with id: {}", savedDomain.getId());
        return domainMapper.toResponse(savedDomain);
    }

    @Override
    @Transactional
    public PlacementPostResponse createDomainWithFiles(
            PlacementPostCreateRequest request,
            MultipartFile iconImage,
            MultipartFile bannerImage,
            MultipartFile featureImage,
            MultipartFile propertyViewPdf) {
        
        log.info("Creating new domain with files: {}", request.getName());

        // if (request.getSeoUrl() != null && domainRepository.existsBySeoUrl(request.getSeoUrl())) {
        //     throw new IllegalArgumentException("Domain with SEO URL '" + request.getSeoUrl() + "' already exists");
        // }

        // Upload files and get URLs
        if (iconImage != null && !iconImage.isEmpty()) {
            String iconPath = fileStorageService.storeFile(iconImage, "icons");
            request.setIconImage(fileStorageService.getFileUrl(iconPath));
        }

        if (bannerImage != null && !bannerImage.isEmpty()) {
            String bannerPath = fileStorageService.storeFile(bannerImage, "banners");
            request.setBannerImage(fileStorageService.getFileUrl(bannerPath));
        }

        if (featureImage != null && !featureImage.isEmpty()) {
            String featurePath = fileStorageService.storeFile(featureImage, "features");
            request.setFeatureImage(fileStorageService.getFileUrl(featurePath));
        }

        if (propertyViewPdf != null && !propertyViewPdf.isEmpty()) {
            String pdfPath = fileStorageService.storeFile(propertyViewPdf, "pdfs");
            request.setPropertyViewPdf(fileStorageService.getFileUrl(pdfPath));
        }

        PlacementPost domain = domainMapper.toEntity(request);
        PlacementPost savedDomain = domainRepository.save(domain);

        log.info("Domain created successfully with files, id: {}", savedDomain.getId());
        return domainMapper.toResponse(savedDomain);
    }

    @Override
    @Transactional
    public PlacementPostResponse updateDomain(Long id, PlacementPostUpdateRequest request) {
        log.info("Updating domain with id: {}", id);

        PlacementPost domain = domainRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Domain not found with id: " + id));

        // if (request.getSeoUrl() != null && 
        //     domainRepository.existsBySeoUrlAndIdNot(request.getSeoUrl(), id)) {
        //     throw new IllegalArgumentException("Domain with SEO URL '" + request.getSeoUrl() + "' already exists");
        // }

        domainMapper.updateEntityFromRequest(domain, request);
        PlacementPost updatedDomain = domainRepository.save(domain);

        log.info("Domain updated successfully with id: {}", id);
        return domainMapper.toResponse(updatedDomain);
    }

    @Override
    @Transactional
    public PlacementPostResponse updateDomainWithFiles(
            Long id,
            PlacementPostUpdateRequest request,
            MultipartFile iconImage,
            MultipartFile bannerImage,
            MultipartFile featureImage,
            MultipartFile propertyViewPdf) {
        
        log.info("Updating domain with files, id: {}", id);

        PlacementPost domain = domainRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Domain not found with id: " + id));

        // if (request.getSeoUrl() != null && 
        //     domainRepository.existsBySeoUrlAndIdNot(request.getSeoUrl(), id)) {
        //     throw new IllegalArgumentException("Domain with SEO URL '" + request.getSeoUrl() + "' already exists");
        // }

        // Upload new files and update URLs
        if (iconImage != null && !iconImage.isEmpty()) {
            // Delete old file if exists
            if (domain.getIconImage() != null) {
                deleteOldFile(domain.getIconImage());
            }
            String iconPath = fileStorageService.storeFile(iconImage, "icons");
            request.setIconImage(fileStorageService.getFileUrl(iconPath));
        }

        if (bannerImage != null && !bannerImage.isEmpty()) {
            if (domain.getBannerImage() != null) {
                deleteOldFile(domain.getBannerImage());
            }
            String bannerPath = fileStorageService.storeFile(bannerImage, "banners");
            request.setBannerImage(fileStorageService.getFileUrl(bannerPath));
        }

        if (featureImage != null && !featureImage.isEmpty()) {
            if (domain.getFeatureImage() != null) {
                deleteOldFile(domain.getFeatureImage());
            }
            String featurePath = fileStorageService.storeFile(featureImage, "features");
            request.setFeatureImage(fileStorageService.getFileUrl(featurePath));
        }


        domainMapper.updateEntityFromRequest(domain, request);
        PlacementPost updatedDomain = domainRepository.save(domain);

        log.info("Domain updated successfully with files, id: {}", id);
        return domainMapper.toResponse(updatedDomain);
    }

    @Override
    @Transactional
    public PlacementPostResponse updateDomainImage(Long id, MultipartFile file, String imageType) {
        log.info("Updating {} image for domain id: {}", imageType, id);

        PlacementPost domain = domainRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("PlacementPost not found with id: " + id));

        String directory;
        String oldImageUrl;

        switch (imageType.toLowerCase()) {
            case "icon":
                directory = "icons";
                oldImageUrl = domain.getIconImage();
                break;
            case "banner":
                directory = "banners";
                oldImageUrl = domain.getBannerImage();
                break;
            case "feature":
                directory = "features";
                oldImageUrl = domain.getFeatureImage();
                break;
            default:
                throw new IllegalArgumentException("Invalid image type: " + imageType);
        }

        // Delete old file if exists
        if (oldImageUrl != null) {
            deleteOldFile(oldImageUrl);
        }

        // Upload new file
        String filePath = fileStorageService.storeFile(file, directory);
        String fileUrl = fileStorageService.getFileUrl(filePath);

        // Update domain
        switch (imageType.toLowerCase()) {
            case "icon":
                domain.setIconImage(fileUrl);
                break;
            case "banner":
                domain.setBannerImage(fileUrl);
                break;
            case "feature":
                domain.setFeatureImage(fileUrl);
                break;
        }

        PlacementPost updatedDomain = domainRepository.save(domain);
        log.info("{} image updated successfully for domain id: {}", imageType, id);
        
        return domainMapper.toResponse(updatedDomain);
    }

    @Override
    public PlacementPostResponse getDomainById(Long id) {
        log.info("Fetching PlacementPost with id: {}", id);

       PlacementPost domain = domainRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("PlacementPost not found with id: " + id));

        return domainMapper.toResponse(domain);
    }

//     @Override
//     public PlacementPostResponse getDomainBySeoUrl(String seoUrl) {
//         log.info("Fetching PlacementPost with SEO URL: {}", seoUrl);

//   PlacementPost domain = domainRepository.findBySeoUrl(seoUrl)
//                 .orElseThrow(() -> new ResourceNotFoundException("PlacementPost not found with SEO URL: " + seoUrl));

//         return domainMapper.toResponse(domain);
//     }

    @Override
    public PageResponse<PlacementPostResponse> getAllDomains(Pageable pageable) {
        log.info("Fetching all domains with page: {}, size: {}", pageable.getPageNumber(), pageable.getPageSize());

        Page<PlacementPost> domainPage = domainRepository.findAll(pageable);
        return convertToPageResponse(domainPage);
    }

    @Override
    public PageResponse<PlacementPostResponse> getDomainsByStatus(String status, Pageable pageable) {
        log.info("Fetching PlacementPost with status: {}", status);

        Page<PlacementPost> domainPage = domainRepository.findByStatus(status, pageable);
        return convertToPageResponse(domainPage);
    }

    @Override
    public PageResponse<PlacementPostResponse> getTrendingDomains(Pageable pageable) {
        log.info("Fetching trending PlacementPost");

        Page<PlacementPost> domainPage = domainRepository.findByTrendingTrue(pageable);
        return convertToPageResponse(domainPage);
    }

    @Override
    public PageResponse<PlacementPostResponse> getPopularDomains(Pageable pageable) {
        log.info("Fetching popular PlacementPost");

        Page<PlacementPost> domainPage = domainRepository.findByPopularTrue(pageable);
        return convertToPageResponse(domainPage);
    }

    @Override
    public PageResponse<PlacementPostResponse> getLatestDomains(Pageable pageable) {
        log.info("Fetching latest domains");

        Page<PlacementPost> domainPage = domainRepository.findByLatestTrue(pageable);
        return convertToPageResponse(domainPage);
    }

    @Override
    public PageResponse<PlacementPostResponse> getDomainsByLocationId(String locationId, Pageable pageable) {
        log.info("Fetching PlacementPost with location id: {}", locationId);

        Page<PlacementPost> domainPage = domainRepository.findByLocationId(locationId, pageable);
        return convertToPageResponse(domainPage);
    }

    @Override
    public PageResponse<PlacementPostResponse> searchDomains(String keyword, Pageable pageable) {
        log.info("Searching PlacementPost with keyword: {}", keyword);

        Page<PlacementPost> domainPage = domainRepository.searchByKeyword(keyword, pageable);
        return convertToPageResponse(domainPage);
    }

    @Override
    public PageResponse<PlacementPostResponse> searchDomainsByStatusAndKeyword(String status, String keyword, Pageable pageable) {
        log.info("Searching PlacementPost with status: {} and keyword: {}", status, keyword);

        Page<PlacementPost> domainPage = domainRepository.findByStatusAndKeyword(status, keyword, pageable);
        return convertToPageResponse(domainPage);
    }

    @Override
    @Transactional
    public void deleteDomain(Long id) {
        log.info("Deleting domain with id: {}", id);

        PlacementPost domain = domainRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("PlacementPost not found with id: " + id));

        // Delete associated files
        if (domain.getIconImage() != null) {
            deleteOldFile(domain.getIconImage());
        }
        if (domain.getBannerImage() != null) {
            deleteOldFile(domain.getBannerImage());
        }
        if (domain.getFeatureImage() != null) {
            deleteOldFile(domain.getFeatureImage());
        }
      

        domainRepository.deleteById(id);
        log.info("Domain deleted successfully with id: {}", id);
    }

    @Override
    @Transactional
    public void softDeleteDomain(Long id) {
        log.info("Soft deleting domain with id: {}", id);

        PlacementPost domain = domainRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("PlacementPost not found with id: " + id));

        domain.setStatus("INACTIVE");
        domainRepository.save(domain);

        log.info("PlacementPost soft deleted successfully with id: {}", id);
    }

    private PageResponse<PlacementPostResponse> convertToPageResponse(Page<PlacementPost> domainPage) {
        List<PlacementPostResponse> responses = domainPage.getContent().stream()
                .map(domainMapper::toResponse)
                .collect(Collectors.toList());

        return PageResponse.<PlacementPostResponse>builder()
                .content(responses)
                .pageNumber(domainPage.getNumber())
                .pageSize(domainPage.getSize())
                .totalElements(domainPage.getTotalElements())
                .totalPages(domainPage.getTotalPages())
                .isLast(domainPage.isLast())
                .isFirst(domainPage.isFirst())
                .hasNext(domainPage.hasNext())
                .hasPrevious(domainPage.hasPrevious())
                .build();
    }

    private void deleteOldFile(String fileUrl) {
        try {
            // Extract file path from URL
            String filePath = fileUrl.substring(fileUrl.indexOf("/api/v1/files/") + 14);
            String[] parts = filePath.split("/");
            if (parts.length >= 2) {
                String directory = parts[0];
                String fileName = parts[1];
                fileStorageService.deleteFile(fileName, directory);
            }
        } catch (Exception e) {
            log.warn("Failed to delete old file: {}", fileUrl, e);
        }
    }
}