package com.softcrayons.usersmanagementsystem.service.serviceImpl;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.softcrayons.usersmanagementsystem.dto.banner.BannerRequest;
import com.softcrayons.usersmanagementsystem.dto.banner.BannerResponse;
import com.softcrayons.usersmanagementsystem.dto.banner.PageResponse;
import com.softcrayons.usersmanagementsystem.entity.Banner;
import com.softcrayons.usersmanagementsystem.exception.ResourceNotFoundException;
import com.softcrayons.usersmanagementsystem.repository.BannerRepository;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional(readOnly = true)
public class BannerService {

    private final BannerRepository bannerRepository;

    public PageResponse<BannerResponse> getAllBanners(int page, int size, String sortBy, String direction) {
        log.info("Fetching banners - page: {}, size: {}, sortBy: {}, direction: {}", 
                 page, size, sortBy, direction);
        
        Sort.Direction sortDirection = direction.equalsIgnoreCase("desc") ? 
                                        Sort.Direction.DESC : Sort.Direction.ASC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortDirection, sortBy));
        
        Page<Banner> bannerPage = bannerRepository.findAll(pageable);
        return mapToPageResponse(bannerPage);
    }

    public PageResponse<BannerResponse> getActiveBanners(int page, int size, String sortBy, String direction) {
        log.info("Fetching active banners - page: {}, size: {}", page, size);
        
        Sort.Direction sortDirection = direction.equalsIgnoreCase("desc") ? 
                                        Sort.Direction.DESC : Sort.Direction.ASC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortDirection, sortBy));
        
        Page<Banner> bannerPage = bannerRepository.findByActiveTrue(pageable);
        return mapToPageResponse(bannerPage);
    }

    public PageResponse<BannerResponse> searchBanners(String search, int page, int size) {
        log.info("Searching banners with query: {}", search);
        
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        Page<Banner> bannerPage = bannerRepository.searchBanners(search, pageable);
        
        return mapToPageResponse(bannerPage);
    }

    public BannerResponse getBannerById(Long id) {
        log.info("Fetching banner with id: {}", id);
        
        Banner banner = bannerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Banner not found with id: " + id));
        
        return mapToResponse(banner);
    }

    @Transactional
    public BannerResponse createBanner(BannerRequest request) {
        log.info("Creating new banner with title: {}", request.getTitle());
        
        Banner banner = Banner.builder()
                .title(request.getTitle())
                .name(request.getName())
                .imageUrl(request.getImageUrl())
                .iconPosition(request.getIconPosition())
                .description(request.getDescription())
                .active(request.getActive() != null ? request.getActive() : true)
                .displayOrder(request.getDisplayOrder())
                .build();
        
        Banner savedBanner = bannerRepository.save(banner);
        log.info("Banner created successfully with id: {}", savedBanner.getId());
        
        return mapToResponse(savedBanner);
    }

    @Transactional
    public BannerResponse updateBanner(Long id, BannerRequest request) {
        log.info("Updating banner with id: {}", id);
        
        Banner banner = bannerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Banner not found with id: " + id));
        
        banner.setTitle(request.getTitle());
        banner.setName(request.getName());
        banner.setImageUrl(request.getImageUrl());
        banner.setIconPosition(request.getIconPosition());
        banner.setDescription(request.getDescription());
        banner.setActive(request.getActive());
        banner.setDisplayOrder(request.getDisplayOrder());
        
        Banner updatedBanner = bannerRepository.save(banner);
        log.info("Banner updated successfully with id: {}", updatedBanner.getId());
        
        return mapToResponse(updatedBanner);
    }

    @Transactional
    public void deleteBanner(Long id) {
        log.info("Deleting banner with id: {}", id);
        
        if (!bannerRepository.existsById(id)) {
            throw new ResourceNotFoundException("Banner not found with id: " + id);
        }
        
        bannerRepository.deleteById(id);
        log.info("Banner deleted successfully with id: {}", id);
    }

    @Transactional
    public BannerResponse toggleBannerStatus(Long id) {
        log.info("Toggling banner status for id: {}", id);
        
        Banner banner = bannerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Banner not found with id: " + id));
        
        banner.setActive(!banner.getActive());
        Banner updatedBanner = bannerRepository.save(banner);
        
        log.info("Banner status toggled to {} for id: {}", updatedBanner.getActive(), id);
        return mapToResponse(updatedBanner);
    }

    private BannerResponse mapToResponse(Banner banner) {
        return BannerResponse.builder()
                .id(banner.getId())
                .title(banner.getTitle())
                .name(banner.getName())
                .imageUrl(banner.getImageUrl())
                .iconPosition(banner.getIconPosition())
                .description(banner.getDescription())
                .active(banner.getActive())
                .displayOrder(banner.getDisplayOrder())
                .createdAt(banner.getCreatedAt())
                .updatedAt(banner.getUpdatedAt())
                .build();
    }

    private PageResponse<BannerResponse> mapToPageResponse(Page<Banner> page) {
        List<BannerResponse> content = page.getContent().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
        
        return PageResponse.<BannerResponse>builder()
                .content(content)
                .pageNumber(page.getNumber())
                .pageSize(page.getSize())
                .totalElements(page.getTotalElements())
                .totalPages(page.getTotalPages())
                .first(page.isFirst())
                .last(page.isLast())
                .empty(page.isEmpty())
                .build();
    }
}
