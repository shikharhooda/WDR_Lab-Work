package com.softcrayons.usersmanagementsystem.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.softcrayons.usersmanagementsystem.exception.InvalidImageFormatException;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.util.UUID;

@Component
public class FileUtil {

    private static String UPLOAD_DIR;

    @Value("${file.banner-upload-dir}")
    public void setUploadDir(String uploadDir) {
        FileUtil.UPLOAD_DIR = uploadDir;
    }

    public static String saveImage(MultipartFile file) throws IOException {
        if (file == null || file.isEmpty()) {
            throw new InvalidImageFormatException("Image file is required.");
        }

        if (!file.getContentType().equals("image/webp")) {
            throw new InvalidImageFormatException("Only .webp images are allowed.");
        }

        String ext = StringUtils.getFilenameExtension(file.getOriginalFilename());
        String filename = UUID.randomUUID() + "." + ext;

        File dir = new File(UPLOAD_DIR);
        if (!dir.exists()) {
            dir.mkdirs();
        }

        Path path = Paths.get(UPLOAD_DIR , filename);
        Files.write(path, file.getBytes());

        return path.toString().replace("\\", "/");
    }

    public static void deleteImage(String path) {
        if (path != null && !path.isEmpty()) {
            try {
                Files.deleteIfExists(Paths.get(path));
            } catch (IOException e) {
                System.err.println("Failed to delete image: " + path);
                e.printStackTrace();
            }
        }
    }
}
