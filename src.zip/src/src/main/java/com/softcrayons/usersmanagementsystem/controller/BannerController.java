package com.softcrayons.usersmanagementsystem.controller;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import com.softcrayons.usersmanagementsystem.dto.banner.BannerRequest;
import com.softcrayons.usersmanagementsystem.dto.banner.BannerResponse;
import com.softcrayons.usersmanagementsystem.dto.banner.PageResponse;
import com.softcrayons.usersmanagementsystem.service.serviceImpl.BannerService;

@RestController
@RequestMapping("/api/v1/banners")
public class BannerController {

    @Autowired
    private BannerService bannerService;

    @PostMapping
    public ResponseEntity<BannerResponse> createBanner(@Valid @RequestBody BannerRequest request) {
        return new ResponseEntity<>(bannerService.createBanner(request), HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<PageResponse<BannerResponse>> getAllBanners(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "desc") String direction
    ) {
        return ResponseEntity.ok(bannerService.getAllBanners(page, size, sortBy, direction));
    }

    @GetMapping("/{id}")
    public ResponseEntity<BannerResponse> getBannerById(@PathVariable Long id) {
        return ResponseEntity.ok(bannerService.getBannerById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<BannerResponse> updateBanner(@PathVariable Long id, @Valid @RequestBody BannerRequest request) {
        return ResponseEntity.ok(bannerService.updateBanner(id, request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBanner(@PathVariable Long id) {
        bannerService.deleteBanner(id);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{id}/toggle")
    public ResponseEntity<BannerResponse> toggleBanner(@PathVariable Long id) {
        return ResponseEntity.ok(bannerService.toggleBannerStatus(id));
    }
}
