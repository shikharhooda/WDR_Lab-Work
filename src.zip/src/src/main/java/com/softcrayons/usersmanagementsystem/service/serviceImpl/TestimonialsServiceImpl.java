package com.softcrayons.usersmanagementsystem.service.serviceImpl;
import com.softcrayons.usersmanagementsystem.dto.TestimonialsDto;
import com.softcrayons.usersmanagementsystem.entity.Testimonials;
import com.softcrayons.usersmanagementsystem.repository.TestimonialsRepository;
import com.softcrayons.usersmanagementsystem.service.TestimonialsService;
import com.softcrayons.usersmanagementsystem.util.FileStorageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TestimonialsServiceImpl implements TestimonialsService {

 private final TestimonialsRepository repository;
    
   @Autowired
    private FileStorageService fileStorageService;

    @Value("${file.upload-dir}")
    private String uploadDir;

    public TestimonialsServiceImpl(TestimonialsRepository repository) {
        this.repository = repository;
    }

    // private String storeFile(MultipartFile file, String subDir) throws IOException {
    //     if (file == null || file.isEmpty()) return null;

    //     Path dir = Paths.get(uploadDir, subDir);
    //     Files.createDirectories(dir);

    //     String ext = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf("."));
    //     String fileName = UUID.randomUUID() + ext;
    //     Path target = dir.resolve(fileName);
    //     Files.copy(file.getInputStream(), target, StandardCopyOption.REPLACE_EXISTING);
    //     return subDir + "/" + fileName;
    // }

    private TestimonialsDto mapToDto(Testimonials entity) {
        TestimonialsDto dto = new TestimonialsDto();
        dto.setId(entity.getId());
        dto.setName(entity.getName());
        dto.setEducation(entity.getEducation());
        dto.setCourse(entity.getCourse());
        dto.setCompany(entity.getCompany());
        dto.setDesignation(entity.getDesignation());
        dto.setRating(entity.getRating());
        dto.setReview(entity.getReview());
        dto.setFacebookLink(entity.getFacebookLink());
        dto.setLinkdinLink(entity.getLinkdinLink());
        dto.setEmail(entity.getEmail());
        dto.setContact(entity.getContact());
        dto.setVideoUrl(entity.getVideoUrl());
        return dto;
    }

    private Testimonials mapToEntity(TestimonialsDto dto) {
        Testimonials entity = new Testimonials();
        entity.setId(dto.getId());
        entity.setName(dto.getName());
        entity.setEducation(dto.getEducation());
        entity.setCourse(dto.getCourse());
        entity.setCompany(dto.getCompany());
        entity.setDesignation(dto.getDesignation());
        entity.setRating(dto.getRating());
        entity.setReview(dto.getReview());
        entity.setFacebookLink(dto.getFacebookLink());
        entity.setLinkdinLink(dto.getLinkdinLink());
        entity.setEmail(dto.getEmail());
        entity.setContact(dto.getContact());
        entity.setVideoUrl(dto.getVideoUrl());
        return entity;
    }

    @Override
    public TestimonialsDto create(TestimonialsDto dto, MultipartFile profileImage, MultipartFile bannerImage) throws IOException {
        Testimonials entity = mapToEntity(dto);
        entity.setProfilePicture(fileStorageService.storeMultipartFile(profileImage, uploadDir));
        entity.setImageBanner(fileStorageService.storeMultipartFile(bannerImage, uploadDir));
        return mapToDto(repository.save(entity));
    }

    @Override
    public TestimonialsDto update(Long id, TestimonialsDto dto, MultipartFile profileImage, MultipartFile bannerImage) throws IOException {
        Testimonials entity = repository.findById(id).orElseThrow(() -> new RuntimeException("Testimonial not found"));
        entity.setName(dto.getName());
        entity.setEducation(dto.getEducation());
        entity.setCourse(dto.getCourse());
        entity.setCompany(dto.getCompany());
        entity.setDesignation(dto.getDesignation());
        entity.setRating(dto.getRating());
        entity.setReview(dto.getReview());
        entity.setFacebookLink(dto.getFacebookLink());
        entity.setLinkdinLink(dto.getLinkdinLink());
        entity.setEmail(dto.getEmail());
        entity.setContact(dto.getContact());
        entity.setVideoUrl(dto.getVideoUrl());
        if (profileImage != null && !profileImage.isEmpty()) {
            entity.setProfilePicture(fileStorageService.storeMultipartFile(profileImage, uploadDir));
        }
        if (bannerImage != null && !bannerImage.isEmpty()) {
            entity.setImageBanner(fileStorageService.storeMultipartFile(bannerImage, uploadDir));
        }
        return mapToDto(repository.save(entity));
    }

    @Override
    public TestimonialsDto get(Long id) {
        return repository.findById(id).map(this::mapToDto).orElseThrow(() -> new RuntimeException("Not found"));
    }

    @Override
    public List<TestimonialsDto> getAll() {
        return repository.findAll().stream().map(this::mapToDto).collect(Collectors.toList());
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }
}
