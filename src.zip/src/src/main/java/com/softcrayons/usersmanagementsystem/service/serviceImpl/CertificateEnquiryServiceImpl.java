package com.softcrayons.usersmanagementsystem.service.serviceImpl;

import com.softcrayons.usersmanagementsystem.dto.enquiry.CertificateEnquiryDto;
import com.softcrayons.usersmanagementsystem.entity.CertificateEnquiry;
import com.softcrayons.usersmanagementsystem.repository.CertificateEnquiryRepository;
import com.softcrayons.usersmanagementsystem.service.CertificateEnquiryService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CertificateEnquiryServiceImpl implements CertificateEnquiryService {

    private final CertificateEnquiryRepository certificateEnquiryRepository;

    @Override
    public CertificateEnquiryDto createEnquiry(CertificateEnquiryDto dto) {
        CertificateEnquiry enquiry = new CertificateEnquiry();
        BeanUtils.copyProperties(dto, enquiry);
        CertificateEnquiry saved = certificateEnquiryRepository.save(enquiry);
        CertificateEnquiryDto result = new CertificateEnquiryDto();
        BeanUtils.copyProperties(saved, result);
        return result;
    }

    @Override
    public CertificateEnquiryDto getEnquiryById(Long id) {
        return certificateEnquiryRepository.findById(id)
                .map(enquiry -> {
                    CertificateEnquiryDto dto = new CertificateEnquiryDto();
                    BeanUtils.copyProperties(enquiry, dto);
                    return dto;
                })
                .orElseThrow(() -> new RuntimeException("Certificate Enquiry not found with id: " + id));
    }

    @Override
    public List<CertificateEnquiryDto> getAllEnquiries() {
        return certificateEnquiryRepository.findAll().stream()
                .map(enquiry -> {
                    CertificateEnquiryDto dto = new CertificateEnquiryDto();
                    BeanUtils.copyProperties(enquiry, dto);
                    return dto;
                })
                .collect(Collectors.toList());
    }

    @Override
    public void deleteEnquiry(Long id) {
        if (!certificateEnquiryRepository.existsById(id)) {
            throw new RuntimeException("Cannot delete. Certificate Enquiry not found with id: " + id);
        }
        certificateEnquiryRepository.deleteById(id);
    }
}
