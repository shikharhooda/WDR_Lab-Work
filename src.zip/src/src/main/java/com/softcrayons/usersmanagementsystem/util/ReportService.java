package com.softcrayons.usersmanagementsystem.util;

import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import com.softcrayons.usersmanagementsystem.entity.Student;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import jakarta.mail.internet.MimeMessage;
import javax.sql.DataSource;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.util.*;

@Service
public class ReportService {
    private static final Logger logger = LoggerFactory.getLogger(ReportService.class);
    
    @Autowired
    private JavaMailSender mailSender;
    
    @Autowired
    private DataSource dataSource; // Inject your database DataSource

    @Async("taskExecutor")
    public void generateAndSendReport(Student student) throws Exception {
        Connection connection = null;
        try {
            InputStream jrxmlStream = getClass().getClassLoader().getResourceAsStream("reports/StudentReceipt.jrxml");
            if (jrxmlStream == null) {
                throw new RuntimeException("JRXML file not found in classpath: reports/StudentReceipt.jrxml");
            }
           

            System.setProperty("jasper.reports.compiler.class", "net.sf.jasperreports.engine.design.JRJdtCompiler");

            JasperReport jasperReport = JasperCompileManager.compileReport(jrxmlStream);
            logger.info("JRXML compiled successfully");

            Map<String, Object> parameters = new HashMap<>();
            parameters.put("reportTitle", "Student Receipt");
            parameters.put("id", student.getStudentId()); // This is the key parameter for your SQL query
          

            connection = dataSource.getConnection();
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, connection);
         
            ByteArrayOutputStream pdfStream = new ByteArrayOutputStream();
            JasperExportManager.exportReportToPdfStream(jasperPrint, pdfStream);
            logger.info("PDF generated successfully, size: {} bytes", pdfStream.size());

            sendEmailWithAttachment(student.getEmail(), pdfStream.toByteArray());
            logger.info("Report sent successfully to email: {}", student.getEmail());

        } catch (Exception e) {
            logger.error("Error generating or sending report for email: " + student.getEmail(), e);
            throw e;
        } finally {
            // Always close the database connection
            if (connection != null) {
                try {
                    connection.close();
                    logger.info("Database connection closed");
                } catch (Exception e) {
                    logger.warn("Error closing database connection", e);
                }
            }
        }
    }

    private void sendEmailWithAttachment(String toEmail, byte[] pdfBytes) throws Exception {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

            helper.setTo(toEmail);
            helper.setSubject("Student Receipt - " + new Date());
            
            String emailBody = String.format(
                "Dear Learner,\n\n" +
                "Please find attached your student receipt.\n\n" +
                "Customer ID: %s\n" +
                "Generated on: %s\n\n" +
                "Best Regards,\n" +
                "Softcrayons Tech Soltuions Private Limited",
                toEmail,
                new Date()
            );
            
            helper.setText(emailBody);
            helper.addAttachment("student_receipt.pdf", new ByteArrayResource(pdfBytes));

            mailSender.send(message);
            logger.info("Email sent successfully to: {}", toEmail);
            
        } catch (Exception e) {
            logger.error("Failed to send email", e);
            throw new RuntimeException("Failed to send email with PDF attachment", e);
        }
    }
  
    public void generateAndSendReportSync(Student student) throws Exception {
        generateAndSendReport(student);
    }
}