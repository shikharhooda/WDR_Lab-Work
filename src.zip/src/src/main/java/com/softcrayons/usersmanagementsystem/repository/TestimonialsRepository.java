package com.softcrayons.usersmanagementsystem.repository;

import com.softcrayons.usersmanagementsystem.entity.Testimonials;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TestimonialsRepository extends JpaRepository<Testimonials, Long> {}
