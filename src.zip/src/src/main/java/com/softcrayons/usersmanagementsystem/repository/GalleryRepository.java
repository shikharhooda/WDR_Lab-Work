package com.softcrayons.usersmanagementsystem.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.softcrayons.usersmanagementsystem.entity.Gallary;

public interface GalleryRepository extends JpaRepository<Gallary, Long> {
}
