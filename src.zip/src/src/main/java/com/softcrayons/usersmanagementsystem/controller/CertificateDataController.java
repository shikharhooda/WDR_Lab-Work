package com.softcrayons.usersmanagementsystem.controller;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import com.softcrayons.usersmanagementsystem.dto.enquiry.CertificateEnquiryDto;
import com.softcrayons.usersmanagementsystem.service.CertificateEnquiryService;
import java.util.List;

@RestController
@RequiredArgsConstructor
public class CertificateDataController {

    private final CertificateEnquiryService certificateEnquiryService;

  
    @PostMapping("public/certificate/addEnquiry")
    public CertificateEnquiryDto create(@RequestBody CertificateEnquiryDto dto) {
        return certificateEnquiryService.createEnquiry(dto);
    }

    // @GetMapping("/{id}")
    // public CertificateEnquiryDto get(@PathVariable Long id) {
    //     return certificateEnquiryService.getEnquiryById(id);
    // }

    @GetMapping("auth/certificate/all")
    public List<CertificateEnquiryDto> getAll() {
        return certificateEnquiryService.getAllEnquiries();
    }

    // @DeleteMapping("/{id}")
    // public void delete(@PathVariable Long id) {
    //     certificateEnquiryService.deleteEnquiry(id);
    // }
}
