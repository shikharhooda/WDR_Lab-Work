package com.softcrayons.usersmanagementsystem.repository;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.softcrayons.usersmanagementsystem.entity.Services;

public interface CourseCategroiesRepository   extends  JpaRepository<Services, Integer>{

    boolean existsBySeoUrl(String url);
    
    Optional<Services> findBySeoUrl(String seoUrl);

    // @SuppressWarnings("null")
    // @Query("SELECT new com.softcrayons.usersmanagementsystem.dto.ServiceDto(s.id, s.name) FROM Services s")
    // List<Services> findAllService();
    
}
