package com.softcrayons.usersmanagementsystem.controller;
import lombok.RequiredArgsConstructor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.softcrayons.usersmanagementsystem.dto.ProfileDto;
import com.softcrayons.usersmanagementsystem.service.ProfileService;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class ProfileController {

    @Autowired
    private final ProfileService profileService;

    @PostMapping("/public/profile")
    public ResponseEntity<ProfileDto> createProfile(
            @RequestPart("data") ProfileDto dto,
            @RequestPart(value = "profileImage", required = false) MultipartFile profileImage,
            @RequestPart(value = "logo", required = false) MultipartFile logo
    ) {
        return ResponseEntity.ok(profileService.createProfile(dto, profileImage, logo));
    }

    @PutMapping("/auth/profile/{id}")
    public ResponseEntity<ProfileDto> updateProfile(
            @PathVariable Long id,
            @RequestPart("data") ProfileDto dto,
            @RequestPart(value = "profileImage", required = false) MultipartFile profileImage,
            @RequestPart(value = "logo", required = false) MultipartFile logo
    ) {
        return ResponseEntity.ok(profileService.updateProfile(id, dto, profileImage, logo));
    }

    @GetMapping("/public/profiles")
    public ResponseEntity<List<ProfileDto>> getAllProfiles() {
        return ResponseEntity.ok(profileService.getAllProfiles());
    }

    @GetMapping("/public/profile/{id}")
    public ResponseEntity<ProfileDto> getProfileById(@PathVariable Long id) {
        return ResponseEntity.ok(profileService.getProfileById(id));
    }

    @DeleteMapping("/auth/profile/delete/{id}")
    public ResponseEntity<Void> deleteProfile(@PathVariable Long id) {
        profileService.deleteProfile(id);
        return ResponseEntity.noContent().build();
    }
}
