package com.softcrayons.usersmanagementsystem.entity;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "Student")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String studentId;
    private String name;
    private String email;
    private String contactNo;
    private String dob;
    private String currentAddress;
    private String permanentAddress;
    private String graduationField;
    private String passoutYear;
    private String working;
    private String agent;
    private String courseName;
    private String duration;
    private String courseType;
    private String location;
    private String startDate;
    private String endDate;

    private String totalAmount;
    private String firstInstallment;
    private String firstInstallmentDate;
    private String secondInstallment;
    private String secondInstallmentDate;
    private String thirdInstallment;
    private String thirdInstallmentDate;
    private String training_shift;
    private String registration_amt;

    private String  syllabusCovered;
    private  String guardianName;
    private String  guardianContact;
    private String  studentStatus;

    private String isFirstInstallmentPaid;
    private String isSecondInstallmentPaid;
    private String isThirdInstallmentPaid;

	


}       