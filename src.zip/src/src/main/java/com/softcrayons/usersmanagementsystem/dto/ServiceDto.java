package com.softcrayons.usersmanagementsystem.dto;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;


@Data
@Getter
@Setter 
public class ServiceDto{

    public ServiceDto(Integer id, String name) {
        this.id = id;
        this.name = name;
    }

    private Integer id;
    private String name;
    private String bannerImage;
}
