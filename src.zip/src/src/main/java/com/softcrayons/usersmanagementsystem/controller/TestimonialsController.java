package com.softcrayons.usersmanagementsystem.controller;

import com.softcrayons.usersmanagementsystem.dto.TestimonialsDto;
import com.softcrayons.usersmanagementsystem.service.TestimonialsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
public class TestimonialsController {

    @Autowired
    private TestimonialsService service;

    @PostMapping("/auth/testimonials")
    public ResponseEntity<TestimonialsDto> create(
        @ModelAttribute TestimonialsDto dto,
        @RequestParam MultipartFile profileImage,
        @RequestParam MultipartFile bannerImage
    ) throws IOException {
        return ResponseEntity.ok(service.create(dto, profileImage, bannerImage));
    }

    @PutMapping("/auth/testimonials/{id}")
    public ResponseEntity<TestimonialsDto> update(
        @PathVariable Long id,
        @ModelAttribute TestimonialsDto dto,
        @RequestParam MultipartFile profileImage,
        @RequestParam MultipartFile bannerImage
    ) throws IOException {
        return ResponseEntity.ok(service.update(id, dto, profileImage, bannerImage));
    }

    @GetMapping("public/testimonials/{id}")
    public ResponseEntity<TestimonialsDto> get(@PathVariable Long id) {
        return ResponseEntity.ok(service.get(id));
    }

    @GetMapping("/public/testimonials")
    public ResponseEntity<List<TestimonialsDto>> getAll() {
        return ResponseEntity.ok(service.getAll());
    }

    @DeleteMapping("/auth/testimonials/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
