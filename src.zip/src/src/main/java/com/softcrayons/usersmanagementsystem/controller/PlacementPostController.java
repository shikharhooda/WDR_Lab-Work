package com.softcrayons.usersmanagementsystem.controller;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.softcrayons.usersmanagementsystem.dto.placementpost.request.PlacementPostCreateRequest;
import com.softcrayons.usersmanagementsystem.dto.placementpost.request.PlacementPostUpdateRequest;
import com.softcrayons.usersmanagementsystem.dto.placementpost.response.PageResponse;
import com.softcrayons.usersmanagementsystem.dto.placementpost.response.PlacementPostResponse;
import com.softcrayons.usersmanagementsystem.service.PlacementPostService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("public/placementpost")
@RequiredArgsConstructor
public class PlacementPostController{

    private final PlacementPostService placementPostService;
    private final ObjectMapper objectMapper;

    @PostMapping
    public ResponseEntity<PlacementPostResponse> createDomain(@Valid @RequestBody PlacementPostCreateRequest request) {
        PlacementPostResponse response = placementPostService.createDomain(request);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @PostMapping(value = "/with-files", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<PlacementPostResponse> createDomainWithFiles(
            @RequestParam("domain") String domainJson,
            @RequestParam(value = "iconImage", required = false) MultipartFile iconImage,
            @RequestParam(value = "bannerImage", required = false) MultipartFile bannerImage,
            @RequestParam(value = "featureImage", required = false) MultipartFile featureImage,
            @RequestParam(value = "propertyViewPdf", required = false) MultipartFile propertyViewPdf) {

        try {
            PlacementPostCreateRequest request = objectMapper.readValue(domainJson, PlacementPostCreateRequest.class);
            PlacementPostResponse response = placementPostService.createDomainWithFiles(
                    request, iconImage, bannerImage, featureImage, propertyViewPdf
            );
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            throw new RuntimeException("Failed to parse domain data", e);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<PlacementPostResponse> updateDomain(
            @PathVariable Long id,
            @Valid @RequestBody PlacementPostUpdateRequest request) {
        PlacementPostResponse response = placementPostService.updateDomain(id, request);
        return ResponseEntity.ok(response);
    }

    @PutMapping(value = "/{id}/with-files", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<PlacementPostResponse> updateDomainWithFiles(
            @PathVariable Long id,
            @RequestParam("domain") String domainJson,
            @RequestParam(value = "iconImage", required = false) MultipartFile iconImage,
            @RequestParam(value = "bannerImage", required = false) MultipartFile bannerImage,
            @RequestParam(value = "featureImage", required = false) MultipartFile featureImage,
            @RequestParam(value = "propertyViewPdf", required = false) MultipartFile propertyViewPdf) {

        try {
            PlacementPostUpdateRequest request = objectMapper.readValue(domainJson, PlacementPostUpdateRequest.class);
           PlacementPostResponse response = placementPostService.updateDomainWithFiles(
                    id, request, iconImage, bannerImage, featureImage, propertyViewPdf
            );
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            throw new RuntimeException("Failed to parse domain data", e);
        }
    }

    @PatchMapping(value = "/{id}/images/{imageType}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<PlacementPostResponse> updateDomainImage(
            @PathVariable Long id,
            @PathVariable String imageType,
            @RequestParam("file") MultipartFile file) {

        PlacementPostResponse response = placementPostService.updateDomainImage(id, file, imageType);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/{id}")
    public ResponseEntity<PlacementPostResponse> getDomainById(@PathVariable Long id) {
       PlacementPostResponse response = placementPostService.getDomainById(id);
        return ResponseEntity.ok(response);
    }

    // @GetMapping("/seo/{seoUrl}")
    // public ResponseEntity<PlacementPostResponse> getDomainBySeoUrl(@PathVariable String seoUrl) {
    //     PlacementPostResponse response = placementPostService.getDomainBySeoUrl(seoUrl);
    //     return ResponseEntity.ok(response);
    // }

    @GetMapping
    public ResponseEntity<PageResponse<PlacementPostResponse>> getAllDomains(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {

        Sort.Direction sortDirection = direction.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortDirection, sortBy));

        PageResponse<PlacementPostResponse> response = placementPostService.getAllDomains(pageable);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<PageResponse<PlacementPostResponse>> getDomainsByStatus(
            @PathVariable String status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {

        Sort.Direction sortDirection = direction.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortDirection, sortBy));

        PageResponse<PlacementPostResponse> response =placementPostService.getDomainsByStatus(status, pageable);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/trending")
    public ResponseEntity<PageResponse<PlacementPostResponse>> getTrendingDomains(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "rating"));
        PageResponse<PlacementPostResponse> response = placementPostService.getTrendingDomains(pageable);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/popular")
    public ResponseEntity<PageResponse<PlacementPostResponse>> getPopularDomains(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "rateCount"));
        PageResponse<PlacementPostResponse> response = placementPostService.getPopularDomains(pageable);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/latest")
    public ResponseEntity<PageResponse<PlacementPostResponse>> getLatestDomains(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        PageResponse<PlacementPostResponse> response = placementPostService.getLatestDomains(pageable);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/location/{locationId}")
    public ResponseEntity<PageResponse<PlacementPostResponse>> getDomainsByLocationId(
            @PathVariable String locationId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {

        Sort.Direction sortDirection = direction.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortDirection, sortBy));

        PageResponse<PlacementPostResponse> response = placementPostService.getDomainsByLocationId(locationId, pageable);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/search")
    public ResponseEntity<PageResponse<PlacementPostResponse>> searchDomains(
            @RequestParam String keyword,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {

        Sort.Direction sortDirection = direction.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortDirection, sortBy));

        PageResponse<PlacementPostResponse> response = placementPostService.searchDomains(keyword, pageable);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/search/advanced")
    public ResponseEntity<PageResponse<PlacementPostResponse>> advancedSearch(
            @RequestParam String status,
            @RequestParam String keyword,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "id"));
        PageResponse<PlacementPostResponse> response = placementPostService.searchDomainsByStatusAndKeyword(status, keyword, pageable);
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDomain(@PathVariable Long id) {
        placementPostService.deleteDomain(id);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{id}/soft-delete")
    public ResponseEntity<Void> softDeleteDomain(@PathVariable Long id) {
        placementPostService.softDeleteDomain(id);
        return ResponseEntity.noContent().build();
    }
}
