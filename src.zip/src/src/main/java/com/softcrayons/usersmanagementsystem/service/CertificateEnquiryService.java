package com.softcrayons.usersmanagementsystem.service;
import java.util.List;

import com.softcrayons.usersmanagementsystem.dto.enquiry.CertificateEnquiryDto;

public interface CertificateEnquiryService {

    CertificateEnquiryDto createEnquiry(CertificateEnquiryDto dto);

    CertificateEnquiryDto getEnquiryById(Long id);

    List<CertificateEnquiryDto> getAllEnquiries();

    void deleteEnquiry(Long id);
    
}
