package com.softcrayons.usersmanagementsystem.service;
import java.util.List;


import com.softcrayons.usersmanagementsystem.dto.blos.BlogDto;


public interface BlogService {
    BlogDto createBlog(BlogDto blogDto);
    BlogDto updateBlog(String url, BlogDto blogDto);
    void deleteBlog(Long id);
    // BlogDto getBlog(Long id);
    BlogDto getBlog(String  seoUrl);
    List<BlogDto> getAllBlogs();
    boolean  isAvailable(String  url);
}
