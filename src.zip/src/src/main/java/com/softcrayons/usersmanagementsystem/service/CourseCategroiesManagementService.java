package com.softcrayons.usersmanagementsystem.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.softcrayons.usersmanagementsystem.entity.Services;
import com.softcrayons.usersmanagementsystem.exception.NoDataFoundException;
import com.softcrayons.usersmanagementsystem.repository.CourseCategroiesRepository;

@Service
public class CourseCategroiesManagementService {
    @Autowired
     private  CourseCategroiesRepository  courseCategroiesRepository;
     
    
       public  List<Services> getAll(){

        List<Services> categories = courseCategroiesRepository.findAll();
        if (categories.isEmpty()) {
            throw new NoDataFoundException("No categories found!");
        }
        return categories;
       }

       
    // public  List<Services>   getAllServiceNames(){
    //     List<Services> categories = courseCategroiesRepository.findAll();
    //     if (categories.isEmpty()) {
    //         throw new NoDataFoundException("No categories found!");
    //     }
    //      return categories ;
    //  }


}
