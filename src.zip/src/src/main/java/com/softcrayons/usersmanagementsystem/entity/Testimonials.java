package com.softcrayons.usersmanagementsystem.entity;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "testimonials")
@Getter
@Setter
public class Testimonials {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @Column(name = "profile_picture")
    private String profilePicture;

    private String education;

    private String course;

    @Column(name = "company")
    private String company;

    private String designation;

    private int rating;

    @Column(length = 2000)
    private String review;

    @Column(name = "image_banner")
    private String imageBanner;

    @Column(name = "facebook_link")
    private String facebookLink;

    @Column(name = "linkedin_link")
    private String linkdinLink;

    private String email;

    private String contact;

    @Column(name = "video_url")
    private String videoUrl;
}
