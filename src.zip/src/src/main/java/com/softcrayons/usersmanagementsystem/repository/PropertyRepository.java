package com.softcrayons.usersmanagementsystem.repository;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.softcrayons.usersmanagementsystem.dto.PropertyTitlesDto;
import com.softcrayons.usersmanagementsystem.entity.Property;


public interface PropertyRepository extends  JpaRepository<Property, Long> {

boolean existsBySeoUrl(String url);
Long  deleteBySeoUrl(String seoUrl);
    
// Optional<Property> findEntityBySeoUrl(String seoUrl);

// @Query("SELECT new com.softcrayons.usersmanagementsystem.dto.PropeDto(s.id, s.name, s.seoUrl,s.heading, s.longDescription, s.description, s.notes, s.featureImage, s.status, s.metaTitle, s.metaKeywords, s.metaDescription, s.bannerImage, s.locationId, s.propertyView, s.instantBookingButton, s.template, s.level, s.lecture, s.duration , s.access, s.certificate, s.recourse , s.icon ,  s.totalEnroll, s.isPopular,  s.rentalAggrementAttachment, s.bannerHeading , s.bannerText, s.googleRate,  s.sulekhaRate, s.urbanRate, s.jdRate, s.facebookRate, s.isHeaderFooter, s.price, s.tags, s.isHome ) FROM Property s WHERE s.seoUrl = :seoUrl")
Optional<Property> findBySeoUrl(@Param("seoUrl") String seoUrl);


@Query("SELECT new com.softcrayons.usersmanagementsystem.dto.PropertyTitlesDto(s.id, s.name, s.seoUrl, s.locationId, s.isPopular,  s.bannerImage, s.featureImage, s.isHome, s.duration,  s.lecture, s.level, s.totalEnroll, s.instantBookingButton) FROM Property s")
List<PropertyTitlesDto> findAllProperties();
    

}
