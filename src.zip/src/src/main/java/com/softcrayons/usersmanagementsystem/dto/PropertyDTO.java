package com.softcrayons.usersmanagementsystem.dto;
import lombok.Data;
import java.sql.Timestamp;

@Data
public class PropertyDTO {
    private Long id;
    private String name;
    private String seoUrl;
    private String heading;
    private String price;
    private String address;
    private String mobile;
    private String email;
    private String website;
    private String shortDescription;
    private String longDescription;
    private String description;

    //  for  faqs
    private String cancellationPolicy;

    //contains  batch      upcoming batch
    private String bookingPolicy;
    
    // contains     features and tools 
    private String notes;

    private String featureImage;
    private String status;

    private String metaTitle;
    private String metaKeywords;
    private String metaDescription;
    
    private String headerSection;
    private String footerSection;
    private Timestamp createdAt;
    private Timestamp updatedAt;
    private String tags;
    private String isHome;
    private String bannerImage;
    private Integer locationId;
    private String propertyStatus;
    private String map;

    //  syllabus
    private String propertyView;
    private String instantBookingButton;
    private String template;
    private Integer ordering;
    private String formType;
    private String level;
    private String lecture;
    private String duration;
    private String access;
    private String certificate;
    private String recourse;
    private String icon;
    private String isHeaderFooter;
    private Integer totalEnroll;
    private String isPopular;
    private String rentalAggrementAttachment;
    private String bannerHeading;
    private String bannerLink;
    private String bannerText;
    private String googleRate;
    private String sulekhaRate;
    private String urbanRate;
    private String jdRate;
    private String facebookRate;
}   