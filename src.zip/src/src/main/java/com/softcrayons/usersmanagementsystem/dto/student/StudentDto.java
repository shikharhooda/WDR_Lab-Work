package com.softcrayons.usersmanagementsystem.dto.student;

import jakarta.annotation.Nonnull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StudentDto {
	
	@Nonnull
	private String  studentId;
    @Nonnull
	private String name;
    @Nonnull
	private String email;
    @Nonnull
	private String contactNo;

    @Nonnull
	private String dob;

	private String currentAddress;
	private String permanentAddress;
	private String graduationField;
	private String passoutYear;
	private String working;
	private String agent;

    @Nonnull
	private String courseName;
    @Nonnull
	private String duration;
    @Nonnull
	private String courseType;
    @Nonnull
	private String location;
    @Nonnull
	private String startDate ;
    @Nonnull
	private String endDate;

    @Nonnull
	private String totalAmount;

    @Nonnull
	private String firstInstallment;
    @Nonnull
	private String firstInstallmentDate;

    @Nonnull
	private String secondInstallment;
    @Nonnull
	private String secondInstallmentDate;

    @Nonnull
	private String thirdInstallment;
    @Nonnull
	private String thirdInstallmentDate;

    @Nonnull
    private String  training_shift;	

	@Nonnull
	private  String  guardianName;
	
	@Nonnull
    private String  guardianContact;

	@Nonnull
    private String registration_amt;

	
	private String studentStatus;

	@Nonnull
	private String isFirstInstallmentPaid;
	@Nonnull
    private String isSecondInstallmentPaid;
	@Nonnull
    private String isThirdInstallmentPaid;

	
}