package com.softcrayons.usersmanagementsystem.util;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@Service
public class WhatsAppService {

    private final String TOKEN = "<YOUR_ACCESS_TOKEN>";
    private final String PHONE_NUMBER_ID = "<YOUR_PHONE_NUMBER_ID>";

    public String sendTextMessage(String to, String message) {
        String url = "https://graph.facebook.com/v17.0/" + PHONE_NUMBER_ID + "/messages";

        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(TOKEN);
        headers.setContentType(MediaType.APPLICATION_JSON);

        Map<String, Object> body = new HashMap<>();
        body.put("messaging_product", "whatsapp");
        body.put("to", to);
        body.put("type", "text");

        Map<String, String> textObj = new HashMap<>();
        textObj.put("body", message);
        body.put("text", textObj);

        HttpEntity<Map<String, Object>> request = new HttpEntity<>(body, headers);

        return restTemplate.postForObject(url, request, String.class);
    }
}
