package com.softcrayons.usersmanagementsystem.dto.banner;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class BannerRequest {
    
    @NotBlank(message = "Title is required")
    @Size(min = 3, max = 200, message = "Title must be between 3 and 200 characters")
    private String title;

    @NotBlank(message = "Name is required")
    @Size(min = 2, max = 100, message = "Name must be between 2 and 100 characters")
    private String name;

    @NotBlank(message = "Image URL is required")
    private String imageUrl;

    @NotBlank(message = "Icon position is required")
    @Pattern(regexp = "LEFT|RIGHT|TOP|BOTTOM|CENTER", 
             message = "Icon position must be one of: LEFT, RIGHT, TOP, BOTTOM, CENTER")
    private String iconPosition;

    @Size(max = 1000, message = "Description cannot exceed 1000 characters")
    private String description;

    private Boolean active;

    private Integer displayOrder;
}
