package com.softcrayons.usersmanagementsystem.dto.placementpost.response;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PlacementPostResponse {
    private Long id;
    @JsonProperty("location_id")
    private String locationId;

    private String name;


    private String title;

    private String location;

    private String description;

    private String highlight;

    private String features;

    private String faqs;

    private String status;

    private Boolean trending;

    private Boolean popular;

    private Boolean latest;

    private Integer rating;

    @JsonProperty("bg_gradient")
    private String bgGradient;

    @JsonProperty("icon_image")
    private String iconImage;

    @JsonProperty("banner_image")
    private String bannerImage;

    @JsonProperty("feature_image")
    private String featureImage;

    @JsonProperty("created_at")
    private LocalDateTime createdAt;

    @JsonProperty("updated_at")
    private LocalDateTime updatedAt;
}