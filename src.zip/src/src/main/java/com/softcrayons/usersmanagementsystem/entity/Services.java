package com.softcrayons.usersmanagementsystem.entity;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.time.Instant;
@Entity
@Table(
    name = "services",
    indexes = {
        @Index(name = "idx_service_name", columnList = "name")
    }
)
@Getter
@Setter
public class Services{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String name;
    @Column(name = "seo_url") 
    private String seoUrl;
    private String short_description;
    private String medium_description;
    private String long_description;
    private String description;
    private String image;
    private String meta_title;
    private String meta_keywords;
    private String meta_description;
    private String templete;
    private String bannerImage;
    private String publish = "published";
    private String footer_section;
    private String header_section;
    private String created_at;
    private String updated_at;

    @PrePersist
    protected void onCreate() {
        created_at = Instant.now()+"";
    }

    @PreUpdate
    protected void onUpdate() {
        updated_at = Instant.now()+"";
    }
}
