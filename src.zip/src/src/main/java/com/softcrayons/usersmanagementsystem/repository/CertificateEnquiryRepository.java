package com.softcrayons.usersmanagementsystem.repository;

import com.softcrayons.usersmanagementsystem.entity.CertificateEnquiry;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CertificateEnquiryRepository extends JpaRepository<CertificateEnquiry, Long> {
}
