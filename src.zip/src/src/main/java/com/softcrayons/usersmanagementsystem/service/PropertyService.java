package com.softcrayons.usersmanagementsystem.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.softcrayons.usersmanagementsystem.dto.PropertyDTO;
import com.softcrayons.usersmanagementsystem.dto.PropertyTitlesDto;
import com.softcrayons.usersmanagementsystem.entity.Property;
import com.softcrayons.usersmanagementsystem.exception.NoDataFoundException;
import com.softcrayons.usersmanagementsystem.exception.PropertyNotFoundException;
import com.softcrayons.usersmanagementsystem.exception.ResourceNotFoundException;
import com.softcrayons.usersmanagementsystem.repository.PropertyRepository;
import com.softcrayons.usersmanagementsystem.util.FileStorageService;

@Service
public class PropertyService {

    @Autowired
    private final PropertyRepository propertyRepository;
    @Autowired
    private final PropertyMapper propertyMapper;

    @Value("${file.upload-dir}")
    private String UPLOAD_DIR;

    @Autowired
    private final FileStorageService fileStorageService;

    public PropertyService(PropertyRepository propertyRepository,
            PropertyMapper propertyMapper,
            FileStorageService fileStorageService,
            @Value("${file.upload-dir}") String uploadDir) {
        this.propertyRepository = propertyRepository;
        this.propertyMapper = propertyMapper;
        this.fileStorageService = fileStorageService;
        this.UPLOAD_DIR = uploadDir;
    }

    public boolean isUrlExists(String url) {
        return propertyRepository.existsBySeoUrl(url);
    }

    public List<PropertyTitlesDto> getAllList() {

        List<PropertyTitlesDto> categories = propertyRepository.findAllProperties();
        if (categories.isEmpty()) {
            throw new NoDataFoundException("No categories found!");
        }
        return categories;
    }

    public Optional<Property> getPropertyById(Long id) {
        return propertyRepository.findById(id);
    }

    public List<Property> getAll() {
        List<Property> properties = propertyRepository.findAll();
        if (properties.isEmpty()) {
            throw new NoDataFoundException("No categories found!");
        }
        return properties;
    }

    public PropertyDTO getPage(String url) {
        Optional<Property> property = propertyRepository.findBySeoUrl(url);
        if (property.isPresent()) {
            PropertyMapper mapper = new PropertyMapper();
            return mapper.toDto(property.get());
        } else {
            throw new PropertyNotFoundException("Property not found for URL: " + url);
        }

    }

    public PropertyDTO saveProperty(String propertyJson, MultipartFile featureImage, MultipartFile bannerImage,
            MultipartFile icon, MultipartFile rentalAggrementAttachment) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        PropertyDTO property = mapper.readValue(propertyJson, PropertyDTO.class);

        // Create the upload directory if it doesn't exist
        Path uploadPath = Paths.get(UPLOAD_DIR + "/");
        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }

        // Handle file uploads
        if (featureImage != null && !featureImage.isEmpty()) {
            String fileName = property.getSeoUrl() + "-feature" + getFileExtension(featureImage.getOriginalFilename());
            Path filePath = uploadPath.resolve(fileName);
            Files.copy(featureImage.getInputStream(), filePath);
            property.setFeatureImage("uploads/properties/" + fileName);
        }

        if (bannerImage != null && !bannerImage.isEmpty()) {
            String fileName = property.getSeoUrl() + "-banner" + getFileExtension(bannerImage.getOriginalFilename());
            Path filePath = uploadPath.resolve(fileName);
            Files.copy(bannerImage.getInputStream(), filePath);
            property.setBannerImage("uploads/properties/" + fileName);
        }

        if (icon != null && !icon.isEmpty()) {
            String fileName = property.getSeoUrl() + "-icon" + getFileExtension(icon.getOriginalFilename());
            Path filePath = uploadPath.resolve(fileName);
            Files.copy(icon.getInputStream(), filePath);
            property.setIcon("uploads/properties/" + fileName);
        }

        if (rentalAggrementAttachment != null && !rentalAggrementAttachment.isEmpty()) {
            String fileName = property.getSeoUrl() + "-pdfsyllabus"
                    + getFileExtension(rentalAggrementAttachment.getOriginalFilename());
            Path filePath = uploadPath.resolve(fileName);
            Files.copy(rentalAggrementAttachment.getInputStream(), filePath);
            property.setRentalAggrementAttachment("uploads/properties/" + fileName);
        }

        Property p = propertyRepository.save(propertyMapper.toEntity(property));
        System.out.println("Method is called ands saved succesfully");
        return propertyMapper.toDto(p);
    }

    public PropertyDTO updatePropertyBySeoUrl(String seoUrl, String propertyJson, MultipartFile featureImage,
            MultipartFile bannerImage, MultipartFile icon, MultipartFile rentalAggrementAttachment) throws IOException {
        // Convert JSON string to PropertyDTO object
        ObjectMapper objectMapper = new ObjectMapper();
        PropertyDTO propertyDTO = objectMapper.readValue(propertyJson, PropertyDTO.class);

        // Find the existing property using seoUrl
        Property existingProperty = propertyRepository.findBySeoUrl(seoUrl)
                .orElseThrow(() -> new ResourceNotFoundException("Property not found with seoUrl " + seoUrl));

        // Store old file names to delete them later
        String oldFeatureImage = existingProperty.getFeatureImage();
        String oldBannerImage = existingProperty.getBannerImage();
        String oldIcon = existingProperty.getIcon();
        String oldRentalAgreement = existingProperty.getRentalAggrementAttachment();


        // Update the property fields with new data
        existingProperty.setName(propertyDTO.getName());
        existingProperty.setDescription(propertyDTO.getDescription());
        existingProperty.setPrice(propertyDTO.getPrice());

        Path uploadPath = Paths.get(UPLOAD_DIR + "/");
        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }

        // Handle file uploads
        if (featureImage != null && !featureImage.isEmpty()) {
            if (oldFeatureImage != null && !oldFeatureImage.isEmpty()) {
                deleteFile(oldFeatureImage);
            }
            String fileName = existingProperty.getSeoUrl() + "-feature"
                    + getFileExtension(featureImage.getOriginalFilename());
            Path filePath = uploadPath.resolve(fileName);
            Files.copy(featureImage.getInputStream(), filePath);
            existingProperty.setFeatureImage("uploads/properties/" + fileName);
        }

        if (bannerImage != null && !bannerImage.isEmpty()) {
            if (oldBannerImage != null && !oldBannerImage.isEmpty()) {
                deleteFile(oldBannerImage);
            }
            String fileName = existingProperty.getSeoUrl() + "-banner"
                    + getFileExtension(bannerImage.getOriginalFilename());
            Path filePath = uploadPath.resolve(fileName);
            Files.copy(bannerImage.getInputStream(), filePath);
            existingProperty.setBannerImage("uploads/properties/" + fileName);
        }

        if (icon != null && !icon.isEmpty()) {
            if (oldIcon != null && !oldIcon.isEmpty()) {
                deleteFile(oldIcon);
            }
            String fileName = existingProperty.getSeoUrl() + "-icon" + getFileExtension(icon.getOriginalFilename());
            Path filePath = uploadPath.resolve(fileName);
            Files.copy(icon.getInputStream(), filePath);
            existingProperty.setIcon("uploads/properties/" + fileName);
        }

        if (rentalAggrementAttachment != null && !rentalAggrementAttachment.isEmpty()) {
            if (oldRentalAgreement != null && !oldRentalAgreement.isEmpty()) {
                deleteFile(oldRentalAgreement);
            }
            String fileName = existingProperty.getSeoUrl() + "-pdfsyllabus"
                    + getFileExtension(rentalAggrementAttachment.getOriginalFilename());
            Path filePath = uploadPath.resolve(fileName);
            Files.copy(rentalAggrementAttachment.getInputStream(), filePath);
            existingProperty.setRentalAggrementAttachment("uploads/properties/" + fileName);
        }
          
        existingProperty.setAccess(propertyDTO.getAccess());
        existingProperty.setBannerHeading(propertyDTO.getBannerHeading());
        existingProperty.setBannerText(propertyDTO.getBannerText());
        existingProperty.setCertificate(propertyDTO.getCertificate());
        existingProperty.setDescription(propertyDTO.getDescription());
        existingProperty.setDuration(propertyDTO.getDuration());
        existingProperty.setFacebookRate(propertyDTO.getFacebookRate());
        existingProperty.setHeading(propertyDTO.getHeading());
        existingProperty.setIsHome(propertyDTO.getIsHome());
        existingProperty.setIsPopular(propertyDTO.getIsPopular());
        existingProperty.setLecture(propertyDTO.getLecture());
        existingProperty.setLevel(propertyDTO.getLevel());
        existingProperty.setLongDescription(propertyDTO.getLongDescription());
        existingProperty.setMetaDescription(propertyDTO.getMetaDescription());
        existingProperty.setDescription(propertyDTO.getDescription());
        existingProperty.setMetaKeywords(propertyDTO.getMetaKeywords());
        existingProperty.setMetaTitle(propertyDTO.getMetaTitle());
        existingProperty.setName(propertyDTO.getName());
        existingProperty.setPrice(propertyDTO.getPrice());
        existingProperty.setRecourse(propertyDTO.getRecourse());
        existingProperty.setSeoUrl(propertyDTO.getSeoUrl());
        existingProperty.setLocationId(propertyDTO.getLocationId());
        existingProperty.setTags(propertyDTO.getTags());
        existingProperty.setTotalEnroll(propertyDTO.getTotalEnroll());
        existingProperty.setShortDescription(propertyDTO.getShortDescription());
        existingProperty.setAccess("1 Year");
        existingProperty.setPropertyView(propertyDTO.getPropertyView());
        existingProperty.setCancellationPolicy(propertyDTO.getCancellationPolicy());
        existingProperty.setBookingPolicy(propertyDTO.getBookingPolicy());
        existingProperty.setNotes(propertyDTO.getNotes());
        // Save the updated property to the database
        Property updatedProperty = propertyRepository.save(existingProperty);

        PropertyMapper mapper = new PropertyMapper();
        PropertyDTO property = mapper.toDto(updatedProperty);
      
        return property;
    }

    private String getFileExtension(String filename) {
    if (filename == null || filename.trim().isEmpty() || !filename.contains(".")) {
        return ""; 
    }
    int dotIndex = filename.lastIndexOf(".");
    if (dotIndex == filename.length() - 1) {
        return "";
    }
    return filename.substring(dotIndex + 1);
}

    private void deleteFile(String fileName) {
        Path filePath = Paths.get(fileName);
        try {
            Files.deleteIfExists(filePath);
            System.out.println("File deleted: " + filePath);
        } catch (IOException e) {
            System.out.println("Error deleting file: " + e.getMessage());
        }
    }

}
