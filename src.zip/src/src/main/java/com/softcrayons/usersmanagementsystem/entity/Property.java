package com.softcrayons.usersmanagementsystem.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import java.sql.Timestamp;

@Entity

@Table(
    name = "properties",
    indexes = {
        @Index(name = "idx_property_seo_url", columnList = "seoUrl", unique = true),
        @Index(name = "idx_property_location", columnList = "locationId"),
        @Index(name = "idx_property_is_popular", columnList = "isPopular"),
        @Index(name = "idx_property_is_home", columnList = "isHome"),
        @Index(name = "idx_property_level", columnList = "level"),
        @Index(name = "idx_property_status", columnList = "status"),
        @Index(name = "idx_property_created_at", columnList = "createdAt")
    }
)

@Data
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Builder
public class Property {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
 
    private String name;
    private String seoUrl;
    private String heading;
    private String price;

    @Lob
    @Column(columnDefinition = "TEXT")  // Medium-sized text
    private String address;

    private String mobile;
    private String email;
    private String website;

    @Lob
    @Column(columnDefinition = "LONGTEXT") // Large text
    private String shortDescription;

    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String longDescription;

    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String description;

    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String cancellationPolicy;

    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String bookingPolicy;

    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String notes;

    private String featureImage;
    private String status ;

    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String metaTitle;

    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String metaKeywords;

    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String metaDescription;

    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String headerSection;

    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String footerSection;

    private Timestamp createdAt;
    private Timestamp updatedAt;

    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String tags;

    private String isHome;
    private String bannerImage;
    private Integer locationId;
    private String propertyStatus;

    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String map;

    private String propertyView;
    private String instantBookingButton;
    private String template;
    private Integer ordering ;
    private String formType;
    private String level;
    private String lecture;
    private String duration;
    private String access;
    private String certificate;
    private String recourse;

    @Lob
    @Column(columnDefinition = "TEXT")
    private String icon;

    private String isHeaderFooter ;
    private Integer totalEnroll;
    private String isPopular ;

    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String rentalAggrementAttachment;

    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String bannerHeading;

    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String bannerLink;

    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String bannerText;
    private String googleRate;
    private String sulekhaRate;
    private String urbanRate;
    private String jdRate;
    private String facebookRate ;
}
