package com.softcrayons.usersmanagementsystem.service;
import org.springframework.data.domain.Pageable;
import org.springframework.web.multipart.MultipartFile;
import com.softcrayons.usersmanagementsystem.dto.placementpost.request.PlacementPostCreateRequest;
import com.softcrayons.usersmanagementsystem.dto.placementpost.request.PlacementPostUpdateRequest;
import com.softcrayons.usersmanagementsystem.dto.placementpost.response.PageResponse;
import com.softcrayons.usersmanagementsystem.dto.placementpost.response.PlacementPostResponse;

public interface PlacementPostService {

    PlacementPostResponse createDomain(PlacementPostCreateRequest request);

    PlacementPostResponse createDomainWithFiles(
            PlacementPostCreateRequest request,
            MultipartFile iconImage,
            MultipartFile bannerImage,
            MultipartFile featureImage,
            MultipartFile propertyViewPdf
    );

    PlacementPostResponse updateDomain(Long id, PlacementPostUpdateRequest request);

    PlacementPostResponse updateDomainWithFiles(
            Long id,
            PlacementPostUpdateRequest request,
            MultipartFile iconImage,
            MultipartFile bannerImage,
            MultipartFile featureImage,
            MultipartFile propertyViewPdf
    );

    PlacementPostResponse getDomainById(Long id);

//     PlacementPostResponse getDomainBySeoUrl(String seoUrl);

    PageResponse<PlacementPostResponse> getAllDomains(Pageable pageable);

    PageResponse<PlacementPostResponse> getDomainsByStatus(String status, Pageable pageable);

    PageResponse<PlacementPostResponse> getTrendingDomains(Pageable pageable);

    PageResponse<PlacementPostResponse> getPopularDomains(Pageable pageable);

    PageResponse<PlacementPostResponse> getLatestDomains(Pageable pageable);

    PageResponse<PlacementPostResponse> getDomainsByLocationId(String locationId, Pageable pageable);

    PageResponse<PlacementPostResponse> searchDomains(String keyword, Pageable pageable);

    PageResponse<PlacementPostResponse> searchDomainsByStatusAndKeyword(String status, String keyword, Pageable pageable);

    void deleteDomain(Long id);

    void softDeleteDomain(Long id);

    PlacementPostResponse updateDomainImage(Long id, MultipartFile file, String imageType);
}