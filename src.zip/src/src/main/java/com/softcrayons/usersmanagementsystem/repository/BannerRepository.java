package com.softcrayons.usersmanagementsystem.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.softcrayons.usersmanagementsystem.entity.Banner;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

@Repository
public interface BannerRepository extends JpaRepository<Banner, Long> {
    Page<Banner> findByActiveTrue(Pageable pageable);
    Page<Banner> findByActiveFalse(Pageable pageable);
    @Query("SELECT b FROM Banner b WHERE " +
           "LOWER(b.title) LIKE LOWER(CONCAT('%', :search, '%')) OR " +
           "LOWER(b.name) LIKE LOWER(CONCAT('%', :search, '%'))")
    Page<Banner> searchBanners(@Param("search") String search, Pageable pageable);
    Optional<Banner> findByIdAndActiveTrue(Long id);
}
