package com.softcrayons.usersmanagementsystem.repository;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.softcrayons.usersmanagementsystem.entity.Placement;

public interface PlacementRepository extends JpaRepository<Placement, Long>{
    
      @SuppressWarnings("null")
      Optional<Placement> findById(Long id);
}
