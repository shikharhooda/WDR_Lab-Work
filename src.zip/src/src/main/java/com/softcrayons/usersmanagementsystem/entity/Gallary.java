package com.softcrayons.usersmanagementsystem.entity;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class Gallary{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "location_id", length = 100)
    private String locationId;

    @Column(name = "name", nullable = false, length = 255)
    private String name;


    @Column(name = "title", length = 500)
    private String title;

    @Column(name = "location", length = 255)
    private String location;

    @Column(name = "description", columnDefinition = "TEXT")
    private String description;





    @Column(name = "faqs", columnDefinition = "TEXT")
    private String faqs;

    @Column(name = "status", length = 20)
    @Builder.Default
    private String status = "ACTIVE";

    @Column(name = "trending")
    @Builder.Default
    private Boolean trending = false;

    @Column(name = "popular")
    @Builder.Default
    private Boolean popular = false;

    @Column(name = "latest")
    @Builder.Default
    private Boolean latest = false;



    @Column(name = "bg_gradient", length = 100)
    private String bgGradient;

    @Column(name = "icon_image", length = 500)
    private String iconImage;

    @Column(name = "banner_image", length = 500)
    private String bannerImage;

    @Column(name = "feature_image", length = 500)
    private String featureImage;


    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Version
    private Long version;

    
}