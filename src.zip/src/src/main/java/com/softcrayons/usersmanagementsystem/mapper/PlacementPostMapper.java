package com.softcrayons.usersmanagementsystem.mapper;
import org.springframework.stereotype.Component;
import com.softcrayons.usersmanagementsystem.dto.placementpost.request.PlacementPostCreateRequest;
import com.softcrayons.usersmanagementsystem.dto.placementpost.request.PlacementPostUpdateRequest;
import com.softcrayons.usersmanagementsystem.dto.placementpost.response.PlacementPostResponse;
import com.softcrayons.usersmanagementsystem.entity.PlacementPost;

@Component
public class PlacementPostMapper {

    public PlacementPost toEntity(PlacementPostCreateRequest request) {
        return PlacementPost.builder()
                .locationId(request.getLocationId())
                .name(request.getName())
                .title(request.getTitle())
                .location(request.getLocation())
                .description(request.getDescription())
                .faqs(request.getFaqs())
                .status(request.getStatus() != null ? request.getStatus() : "ACTIVE")
                .trending(request.getTrending() != null ? request.getTrending() : false)
                .popular(request.getPopular() != null ? request.getPopular() : false)
                .latest(request.getLatest() != null ? request.getLatest() : false)
                .bgGradient(request.getBgGradient())
                .iconImage(request.getIconImage())
                .bannerImage(request.getBannerImage())
                .featureImage(request.getFeatureImage())
                .build();
    }

    public PlacementPostResponse toResponse(PlacementPost domain) {
        return PlacementPostResponse.builder()
                .id(domain.getId())
                .locationId(domain.getLocationId())
                .name(domain.getName())
                .title(domain.getTitle())
                .location(domain.getLocation())
                .description(domain.getDescription())
                .faqs(domain.getFaqs())
                .status(domain.getStatus())
                .trending(domain.getTrending())
                .popular(domain.getPopular())
                .latest(domain.getLatest())
                .bgGradient(domain.getBgGradient())
                .iconImage(domain.getIconImage())
                .bannerImage(domain.getBannerImage())
                .featureImage(domain.getFeatureImage())
                .createdAt(domain.getCreatedAt())
                .updatedAt(domain.getUpdatedAt())
                .build();
    }

    public void updateEntityFromRequest(PlacementPost domain, PlacementPostUpdateRequest request) {
        if (request.getLocationId() != null) {
            domain.setLocationId(request.getLocationId());
        }
        if (request.getName() != null) {
            domain.setName(request.getName());
        }
        if (request.getTitle() != null) {
            domain.setTitle(request.getTitle());
        }
        if (request.getLocation() != null) {
            domain.setLocation(request.getLocation());
        }
        if (request.getDescription() != null) {
            domain.setDescription(request.getDescription());
        }
      
        if (request.getFaqs() != null) {
            domain.setFaqs(request.getFaqs());
        }
       
        if (request.getStatus() != null) {
            domain.setStatus(request.getStatus());
        }
        if (request.getTrending() != null) {
            domain.setTrending(request.getTrending());
        }
        if (request.getPopular() != null) {
            domain.setPopular(request.getPopular());
        }
        if (request.getLatest() != null) {
            domain.setLatest(request.getLatest());
        }
       
        if (request.getBgGradient() != null) {
            domain.setBgGradient(request.getBgGradient());
        }
        if (request.getIconImage() != null) {
            domain.setIconImage(request.getIconImage());
        }
        if (request.getBannerImage() != null) {
            domain.setBannerImage(request.getBannerImage());
        }
        if (request.getFeatureImage() != null) {
            domain.setFeatureImage(request.getFeatureImage());
        }
    }
}