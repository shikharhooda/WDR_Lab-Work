package com.softcrayons.usersmanagementsystem.repository;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;


import com.softcrayons.usersmanagementsystem.entity.Student;

public interface StudentRepository extends JpaRepository<Student, Integer> {
	Optional<Student> findByEmail(String email);
    Optional<Student> findByStudentId(String studentId);
	List<Student> findByContactNo(String contactNo);
	List<Student> findByName(String name);
	List<Student> findByAgent(String agent);
	void deleteByStudentId(String studentId);
    void deleteByEmail(String email);
}