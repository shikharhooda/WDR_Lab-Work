package com.softcrayons.usersmanagementsystem.service;

import org.springframework.core.io.Resource;

import org.springframework.web.multipart.MultipartFile;

public interface FileStorageService {

    // Store a file in a given directory (e.g., "icons", "banners")
    String storeFile(MultipartFile file, String directory);

    // Get the public URL of a stored file
    String getFileUrl(String storedFilePath);

    // Delete a file
    void deleteFile(String fileName, String directory);

    // Load a file as a Resource (for serving via API)
    Resource loadFileAsResource(String directory, String fileName);
}
