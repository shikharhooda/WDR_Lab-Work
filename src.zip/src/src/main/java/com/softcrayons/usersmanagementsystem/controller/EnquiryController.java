package com.softcrayons.usersmanagementsystem.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.softcrayons.usersmanagementsystem.dto.enquiry.EnquiryDto;
import com.softcrayons.usersmanagementsystem.service.EnquiryService;


@RestController
public class EnquiryController {

    @Autowired
    private  EnquiryService enquiryService ;

    @PostMapping("public/addEnquiry")
    public EnquiryDto create(@RequestBody EnquiryDto dto) {
        return enquiryService.saveEnquiry(dto);
    }

    @GetMapping("auth/allEnquiry")
    public List<EnquiryDto> getAll() {
        return enquiryService.getAllEnquiries();
    }

    // @GetMapping("/{id}")
    // public EnquiryDto getOne(@PathVariable Long id) {
    //     return enquiryService.getEnquiryById(id);
    // }

    @PutMapping("/auth/updateEnquiry/{id}")
    public EnquiryDto update(@PathVariable Long id, @RequestBody EnquiryDto dto) {
        System.out.println("update  enquiry----------->?");
        return enquiryService.updateEnquiry(id, dto);
    }

    @DeleteMapping("/admin/deleteEnquiry/{id}")
    public void delete(@PathVariable Long id) {
            System.out.println("delete enquiry----------->?"); 
        enquiryService.deleteEnquiry(id);
    }
}
