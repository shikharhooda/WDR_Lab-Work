package com.softcrayons.usersmanagementsystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.softcrayons.usersmanagementsystem.entity.Services;

public interface ServiceRepository  extends JpaRepository<Services, Integer>{

    
    
}
