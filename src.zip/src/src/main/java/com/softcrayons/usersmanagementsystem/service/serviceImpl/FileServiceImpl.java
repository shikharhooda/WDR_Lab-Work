package com.softcrayons.usersmanagementsystem.service.serviceImpl;


import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.softcrayons.usersmanagementsystem.service.FileStorageService;

import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

@Service
public class FileServiceImpl implements FileStorageService {

    private final Path baseStorageLocation;

    public FileServiceImpl() {
        // Base directory for all uploads
        this.baseStorageLocation = Paths.get("./uploads").toAbsolutePath().normalize();

        try {
            Files.createDirectories(this.baseStorageLocation);
            Files.createDirectories(this.baseStorageLocation.resolve("icons"));
            Files.createDirectories(this.baseStorageLocation.resolve("banners"));
        } catch (IOException e) {
            throw new RuntimeException("Could not create upload directories!", e);
        }

        // Ensure default file exists in icons
        Path defaultIcon = this.baseStorageLocation.resolve("icons/default.jpg");
        if (!Files.exists(defaultIcon)) {
            try {
                Files.createFile(defaultIcon);
            } catch (IOException ex) {
                throw new RuntimeException("Could not create default icon file!", ex);
            }
        }

        // Ensure default file exists in banners
        Path defaultBanner = this.baseStorageLocation.resolve("banners/default.jpg");
        if (!Files.exists(defaultBanner)) {
            try {
                Files.createFile(defaultBanner);
            } catch (IOException ex) {
                throw new RuntimeException("Could not create default banner file!", ex);
            }
        }
    }

    @Override
    public String storeFile(MultipartFile file, String directory) {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("File is empty or null");
        }

        String originalName = StringUtils.cleanPath(file.getOriginalFilename());
        if (originalName.contains("..")) {
            throw new RuntimeException("Invalid file path: " + originalName);
        }

        // Generate unique filename
        String extension = "";
        int extIndex = originalName.lastIndexOf('.');
        if (extIndex > 0) {
            extension = originalName.substring(extIndex);
        }
        String uniqueFileName = UUID.randomUUID().toString() + extension;

        try {
            Path dirPath = this.baseStorageLocation.resolve(directory);
            Files.createDirectories(dirPath);

            Path targetLocation = dirPath.resolve(uniqueFileName);
            Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);

            return directory + "/" + uniqueFileName; // Relative path
        } catch (IOException ex) {
            throw new RuntimeException("Could not store file " + originalName, ex);
        }
    }

    @Override
    public Resource loadFileAsResource(String directory, String fileName) {
        try {
            Path filePath = this.baseStorageLocation.resolve(directory).resolve(fileName).normalize();
            Resource resource = new UrlResource(filePath.toUri());

            if (!resource.exists() || !resource.isReadable()) {
                // Fallback to default file
                Path defaultFile = this.baseStorageLocation.resolve(directory).resolve("default.jpg").normalize();
                resource = new UrlResource(defaultFile.toUri());
            }

            return resource;
        } catch (MalformedURLException ex) {
            throw new RuntimeException("File not found: " + fileName, ex);
        }
    }

    @Override
    public String getFileUrl(String storedFilePath) {
        if (storedFilePath == null || storedFilePath.isEmpty()) {
            return "/files/icons/default.jpg";
        }
        return "/files/" + storedFilePath; // URL for REST endpoint
    }

    @Override
    public void deleteFile(String fileName, String directory) {
        if (fileName == null || fileName.isEmpty()) {
            throw new IllegalArgumentException("Filename cannot be null or empty");
        }

        try {
            Path filePath = this.baseStorageLocation.resolve(directory).resolve(fileName).normalize();
            if (!filePath.startsWith(this.baseStorageLocation)) {
                throw new RuntimeException("Invalid file path");
            }
            Files.deleteIfExists(filePath);
        } catch (IOException ex) {
            throw new RuntimeException("Could not delete file: " + fileName, ex);
        }
    }

    /**
     * Load file from default "icons" directory
     */
    public Resource loadFileAsResource(String fileName) {
        return loadFileAsResource("icons", fileName);
    }
}
