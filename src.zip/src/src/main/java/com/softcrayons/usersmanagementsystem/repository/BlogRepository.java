package com.softcrayons.usersmanagementsystem.repository;

import com.softcrayons.usersmanagementsystem.entity.Blog;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BlogRepository extends JpaRepository<Blog, Long> {
      Optional<Blog> findBySeoUrl(String seoUrl);
}
