package com.softcrayons.usersmanagementsystem.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.web.multipart.MultipartFile;

import com.softcrayons.usersmanagementsystem.dto.PlacementDto;

public interface PlacementService {
    PlacementDto createPlacement(PlacementDto placementDto, MultipartFile image , MultipartFile logo);

    PlacementDto updatePlacement(Long id, PlacementDto placementDto,  MultipartFile image , MultipartFile logo);

    void deletePlacement(Long id);

    PlacementDto getPlacementById(Long id);

    List<PlacementDto> getAllPlacements();
    Page<PlacementDto> getPlacementsPaged(int page, int size);
}