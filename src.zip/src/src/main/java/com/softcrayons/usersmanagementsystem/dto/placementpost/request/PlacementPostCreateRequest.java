package com.softcrayons.usersmanagementsystem.dto.placementpost.request;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PlacementPostCreateRequest{

    @JsonProperty("location_id")
    private String locationId;

    @NotBlank(message = "Name is required")
    @Size(min = 2, max = 255, message = "Name must be between 2 and 255 characters")
    private String name;

 

    @Size(max = 500, message = "Title must not exceed 500 characters")
    private String title;

    @Size(max = 255, message = "Location must not exceed 255 characters")
    private String location;

    private String description;



    private String highlight;

    private String features;

    private String faqs;

    @JsonProperty("terms_condition")
    private String termsCondition;

    @Pattern(regexp = "ACTIVE|INACTIVE|DRAFT", message = "Status must be ACTIVE, INACTIVE, or DRAFT")
    private String status;

    private Boolean trending;

    private Boolean popular;

    private Boolean latest;

    @Min(value = 0, message = "Rating must be at least 0")
    @Max(value = 5, message = "Rating must not exceed 5")
    private Integer rating;

    @JsonProperty("rate_count")
    @Min(value = 0, message = "Rate count must be at least 0")
    private Integer rateCount;

    @JsonProperty("bg_gradient")
    @Size(max = 100, message = "Background gradient must not exceed 100 characters")
    private String bgGradient;

    @JsonProperty("icon_image")
    @Size(max = 500, message = "Icon image URL must not exceed 500 characters")
    private String iconImage;

    @JsonProperty("banner_image")
    @Size(max = 500, message = "Banner image URL must not exceed 500 characters")
    private String bannerImage;

    @JsonProperty("feature_image")
    @Size(max = 500, message = "Feature image URL must not exceed 500 characters")
    private String featureImage;

    @JsonProperty("property_view_pdf")
    @Size(max = 500, message = "Property view PDF URL must not exceed 500 characters")
    private String propertyViewPdf;
}