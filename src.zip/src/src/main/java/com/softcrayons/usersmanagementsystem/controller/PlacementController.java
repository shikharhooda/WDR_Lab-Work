package com.softcrayons.usersmanagementsystem.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.softcrayons.usersmanagementsystem.dto.PlacementDto;
import com.softcrayons.usersmanagementsystem.service.PlacementService;
import lombok.RequiredArgsConstructor;

import org.springframework.data.domain.Page;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@RequiredArgsConstructor
public class PlacementController {

 private final PlacementService placementService;

   

@PostMapping(value = "/public/placement", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
public ResponseEntity<PlacementDto> create(
    @RequestPart("placement") String placementJson,
    @RequestPart("profile") MultipartFile profile,
    @RequestPart("bannerImage") MultipartFile bannerImage
) throws IOException {
    PlacementDto placement = new ObjectMapper().readValue(placementJson, PlacementDto.class);
    return ResponseEntity.ok(placementService.createPlacement(placement, profile, bannerImage));
}


   

   @PutMapping(value = "/public/placement/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
public ResponseEntity<PlacementDto> update(
    @PathVariable Long id,
    @RequestPart("placement") String placementJson,
    @RequestPart(value = "profile", required = false) MultipartFile profile,
    @RequestPart(value = "bannerImage", required = false) MultipartFile bannerImage
) throws IOException {

    PlacementDto placement = new ObjectMapper().readValue(placementJson, PlacementDto.class);

    // Ensure the DTO has the correct ID for updating
    placement.setId(id);

    return ResponseEntity.ok(
        placementService.updatePlacement(id, placement, profile, bannerImage)
    );
}

    @GetMapping("/public/placement/{id}")
    public ResponseEntity<PlacementDto> getPlacementById(@PathVariable Long id) {
        return ResponseEntity.ok(placementService.getPlacementById(id));
         
    }

    @GetMapping("/public/placement/all")
    public ResponseEntity<List<PlacementDto>> getAllPlacements() {
       return ResponseEntity.ok(placementService.getAllPlacements());
         
    }

    @GetMapping("/public/placement/paged")
    public ResponseEntity<Page<PlacementDto>> getPlacementsPaged(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        return ResponseEntity.ok(placementService.getPlacementsPaged(page, size));
      
    }

    @DeleteMapping("/auth/placement/{id}")
    public ResponseEntity<Void> deletePlacement(@PathVariable Long id) {
        placementService.deletePlacement(id);
        return ResponseEntity.noContent().build();
        

    }
}
