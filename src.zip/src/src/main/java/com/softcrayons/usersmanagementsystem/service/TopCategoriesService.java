package com.softcrayons.usersmanagementsystem.service;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import com.softcrayons.usersmanagementsystem.dto.ServicesDto;
import com.softcrayons.usersmanagementsystem.entity.Services;
import com.softcrayons.usersmanagementsystem.exception.NoDataFoundException;
import com.softcrayons.usersmanagementsystem.repository.ServiceRepository;
import com.softcrayons.usersmanagementsystem.util.FileStorageService;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class TopCategoriesService {
  @Autowired
  private ServiceRepository serviceRepository;
  @Autowired
  FileStorageService fileStorageService;

  @Value("${file.upload-dir}")
  private String uploadDir;

  public List<ServicesDto> getAll() {
    List<Services> services = serviceRepository.findAll();

    if (services.isEmpty()) {
      throw new NoDataFoundException("No services found!");
    }

    return services.stream()
        .map(this::mapToDto)
        .collect(Collectors.toList());
  }

  public ServicesDto createService(ServicesDto dto, MultipartFile image, MultipartFile bannerImage) throws IOException {
    Services entity = mapToEntity(dto);
    if (image != null && !image.isEmpty()) {
      entity.setImage(fileStorageService.storeMultipartFile(image, uploadDir));
    }
    if (bannerImage != null && !bannerImage.isEmpty()) {
      entity.setBannerImage(fileStorageService.storeMultipartFile(bannerImage, uploadDir));
    }
    return mapToDto(serviceRepository.save(entity));
  }

  public ServicesDto updateService(Integer id, ServicesDto dto, MultipartFile image, MultipartFile bannerImage)
      throws IOException {
    Services entity = serviceRepository.findById(id).orElseThrow(() -> new RuntimeException("Service not found"));
    entity = mapToEntity(dto);
    entity.setId(id);
    if (image != null && !image.isEmpty()) {
      entity.setImage(fileStorageService.storeMultipartFile(image, uploadDir));
    }
    if (bannerImage != null && !bannerImage.isEmpty()) {
      entity.setBannerImage(fileStorageService.storeMultipartFile(bannerImage, uploadDir));
    }
    return mapToDto(serviceRepository.save(entity));
  }

  public ServicesDto getService(Integer id) {
    Services entity = serviceRepository.findById(id).orElseThrow(() -> new RuntimeException("Service not found"));
    return mapToDto(entity);
  }

  public List<ServicesDto> getAllServices() {
    return serviceRepository.findAll().stream().map(this::mapToDto).collect(Collectors.toList());
  }

  public void deleteService(Integer id) {
    serviceRepository.deleteById(id);
  }

  private ServicesDto mapToDto(Services entity) {
    ServicesDto dto = new ServicesDto();
    dto.setId(entity.getId());
    dto.setName(entity.getName());
    dto.setSeoUrl(entity.getSeoUrl());
    dto.setShortDescription(entity.getShort_description());
    dto.setMediumDescription(entity.getMedium_description());
    dto.setLongDescription(entity.getLong_description());
    dto.setDescription(entity.getDescription());
    dto.setMetaTitle(entity.getMeta_title());
    dto.setMetaKeywords(entity.getMeta_keywords());
    dto.setMetaDescription(entity.getMeta_description());
    dto.setTemplete(entity.getTemplete());
    dto.setPublish(entity.getPublish());
    dto.setFooterSection(entity.getFooter_section());
    dto.setHeaderSection(entity.getHeader_section());
    return dto;
  }

  private Services mapToEntity(ServicesDto dto) {
    Services entity = new Services();
    entity.setName(dto.getName());
    entity.setSeoUrl(dto.getSeoUrl());
    entity.setShort_description(dto.getShortDescription());
    entity.setMedium_description(dto.getMediumDescription());
    entity.setLong_description(dto.getLongDescription());
    entity.setDescription(dto.getDescription());
    entity.setMeta_title(dto.getMetaTitle());
    entity.setMeta_keywords(dto.getMetaKeywords());
    entity.setMeta_description(dto.getMetaDescription());
    entity.setTemplete(dto.getTemplete());
    entity.setPublish(dto.getPublish());
    entity.setFooter_section(dto.getFooterSection());
    entity.setHeader_section(dto.getHeaderSection());
    return entity;
  }

}
