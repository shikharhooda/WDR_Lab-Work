package com.softcrayons.usersmanagementsystem.service.serviceImpl;

import lombok.AllArgsConstructor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.softcrayons.usersmanagementsystem.dto.enquiry.EnquiryDto;
import com.softcrayons.usersmanagementsystem.entity.Enquiry;
import com.softcrayons.usersmanagementsystem.repository.EnquiryRepository;
import com.softcrayons.usersmanagementsystem.service.EnquiryService;
import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class EnquiryServiceImpl implements EnquiryService {

    @Autowired
    private final EnquiryRepository enquiryRepository;

    private EnquiryDto mapToDto(Enquiry enquiry) {
        return EnquiryDto.builder()
                .id(enquiry.getId())
                .name(enquiry.getName())
                .contact(enquiry.getContact())
                .alternateContact(enquiry.getAlternateContact())
                .course(enquiry.getCourse())
                .education(enquiry.getEducation())
                .remarks(enquiry.getRemarks())
                .leadStatus(enquiry.getLeadStatus())
                .email(enquiry.getEmail())
                .address(enquiry.getAddress())
                .assignedDate(enquiry.getAssignedDate())
                .assignedTo(enquiry.getAssignedTo())
                .enquiryDate(enquiry.getEnquiryDate())
                .working(enquiry.getWorking())
                .workingRemarks(enquiry.getWorkingRemarks())
                .availabilityDetails(enquiry.getAvailabilityDetails())
                .build();
    }

    private Enquiry mapToEntity(EnquiryDto dto) {
        return Enquiry.builder()
                .id(dto.getId())
                .name(dto.getName())
                .contact(dto.getContact())
                .alternateContact(dto.getAlternateContact())
                .course(dto.getCourse())
                .education(dto.getEducation())
                .remarks(dto.getRemarks())
                .leadStatus(dto.getLeadStatus())
                .email(dto.getEmail())
                .address(dto.getAddress())
                .assignedDate(dto.getAssignedDate())
                .assignedTo(dto.getAssignedTo())
                .working(dto.getWorking())
                .workingRemarks(dto.getWorkingRemarks())
                .availabilityDetails(dto.getAvailabilityDetails())
                .build();
    }

    @Override
    public EnquiryDto saveEnquiry(EnquiryDto dto) {
        Enquiry enquiry = mapToEntity(dto);
        return mapToDto(enquiryRepository.save(enquiry));
    }

    @Override
    public List<EnquiryDto> getAllEnquiries() {
        return enquiryRepository.findAll()
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    public EnquiryDto getEnquiryById(Long id) {
        return enquiryRepository.findById(id)
                .map(this::mapToDto)
                .orElseThrow(() -> new RuntimeException("Enquiry not found"));
    }

    @Override
    public EnquiryDto updateEnquiry(Long id, EnquiryDto dto) {
        Enquiry existing = enquiryRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Enquiry not found"));
        dto.setId(existing.getId());
        return mapToDto(enquiryRepository.save(mapToEntity(dto)));
    }

    @Override
    public void deleteEnquiry(Long id) {
        enquiryRepository.deleteById(id);
    }
}
