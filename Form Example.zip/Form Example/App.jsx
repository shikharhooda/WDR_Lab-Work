import FormComponent from "./FormComponent"
function App()
{
  return(
    <>
      <FormComponent></FormComponent>
    </>
  )
}

export default App
